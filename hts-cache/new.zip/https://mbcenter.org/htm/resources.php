<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/mbcptemplate2007_2.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="fb:app_id" content="167734213309548"/>
<link rel="shortcut icon" href="/img/mbcp.ico" />
<script type="text/JavaScript" src="/script/genscripts2007.js"></script>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines</title>
<script language="JavaScript" type="text/javascript">
<!--
function MM_displayStatusMsg(msgStr) { //v1.0
  status=msgStr;
  document.MM_returnValue = true;
}
//-->
</script>
<!-- InstanceEndEditable -->
<link href="/css/mainstyle2007.css" rel="stylesheet" type="text/css" />
<!-- InstanceBeginEditable name="head" --> 
<style type="text/css">
<!--
.maintextsmaller {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 9px;
	color: #000000;
}
a.red {
	color: #CC0000;
	text-decoration: none;
	border-bottom-width: 1pt;
	border-bottom-style: solid;
	border-bottom-color: #CC0000;
}
a.red:hover {

	color: #CC9900;
	text-decoration: none;
	border-bottom-width: 1px;
	border-bottom-style: dotted;
	border-bottom-color: #CC9900;
}
-->
</style>
<!-- InstanceEndEditable -->
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=204511906280785";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td bgcolor="#FFFFFF"><img src="/img/banner_main_2007.jpg" alt="Merit Badge Center, Philippines" width="768" height="86" /></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="25%" valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
              </tr>         
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/advancement.php" class="mainlink">Advancement Ranks</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/" class="mainlink" >Merit Badges (Alphabetical)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbcitizenrequired.php" class="mainlink" >Merit Badges (Citizen Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbeaglerequired.php" class="mainlink" >Merit Badges (Eagle Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbelectives.php" class="mainlink" >Merit Badges (Electives)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/ws.php" class="mainlink" >Advancement Worksheets</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/contactus/" class="mainlink" >Contact Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/aboutus.php" class="mainlink" >About Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/sitehelp.php" class="mainlink" >Help</a></td>
              </tr>
			  <tr>
			  	<td class="maintext">&nbsp;</td>
			  </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" --><br />
            <table width="100%" border="0" cellspacing="2" cellpadding="2">
                          <tr>
                            <td class="navbanner">Web Tools </td>
                          </tr>
              <tr>
                            <td><a href="mailto:brokenlinks@meritbadge.org.ph" class="mainlink">Report
                            Broken Links</a></td>
                          </tr>
                        </table>
                        <p>&nbsp;</p>
                        <p><a href="http://www.yehey.com" target="_blank"> </a></p>
            <!-- InstanceEndEditable -->            
              </td>
              <td valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="5">
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><!-- InstanceBeginEditable name="MainBody" --> 
                  <div align="left"> 
                    <h1>Listing of Resource Links</h1>
                    <p class="maintext">Here are all the resource links currently 
                      available for all advancement ranks and merit badges. I 
                      use this page to see all the links and check if they still 
                      exists on a single page. A link colored red means that the link is a <strong>(SKIP)</strong> link. This means that the link is still kept in our database but not visible on that merit badge's resource link. Normally a link is marked as skipped if I am not sure whether or not the website it resolves to still exists or not. </p>
                    <p class="fineprint">Database last reviewed March 19, 2009 </p>
                    <p>
                      <blockquote></blockquote><h2>Boy Scout Membership Badge</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.msc.edu.ph/centennial/anthem.html" target="_blank">Lupang Hinirang</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_ideals.pdf" target="_blank">Ideals of Scouting</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Tenderfoot Class Scout</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.nsc.org/" target="_blank">National Safety Council</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_flag101.pdf" target="_blank">History of the Philippine Flag</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Second Class Scout</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.animatedknots.com/" target="_blank">Animated Knots</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.msc.edu.ph/centennial/display.html" target="_blank">Displaying the Flag</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.hikingforums.net/" target="_blank">Hiking Forums</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_compass.pdf" target="_blank">Compass Reading</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_estimation.pdf" target="_blank">Estimation</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_firstaid.pdf" target="_blank">First Aid</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_ideals.pdf" target="_blank">Ideals of Scouting</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>First Class Scout</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_firstaid.pdf" target="_blank">First Aid</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_morsecode.pdf" target="_blank">International Morse Code</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Senior Scout Membership Badge</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_ideals.pdf" target="_blank">Ideals of Scouting</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Explorer Scout</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.msc.edu.ph/centennial/display.html" target="_blank">Displaying the Flag</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.hikingforums.net/" target="_blank">Hiking Forums</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_firstaid.pdf" target="_blank">First Aid</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_morsecode.pdf" target="_blank">International Morse Code</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Pathfinder Scout</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.hikingforums.net/" target="_blank">Hiking Forums</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.nsc.org/" target="_blank">National Safety Council</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.scoutingresources.org.uk/codes/codes_tracking.html" target="_blank">Tracking Signs: UK Scouting Resources</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_firstaid.pdf" target="_blank">First Aid</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_northwocompass.pdf" target="_blank">North Without a Compass</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Outdoorsman Scout</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Venturer Scout</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="https://lnt.org/learn" target="_blank">Leave No Trace Resources</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Eagle Scout</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://ammo.com/articles/surviving-in-the-wild" target="_blank">Wilderness Survival Guide</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Membership Badge</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/downloads/BS-Passport-FINAL.pdf" target="_blank">Advancement Passport</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Tenderfoot Scout</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/downloads/BS-Passport-FINAL.pdf" target="_blank">Advancement Passport</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Second Class Scout</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/downloads/BS-Passport-FINAL.pdf" target="_blank">Advancement Passport</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>First Class Scout</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/downloads/BS-Passport-FINAL.pdf" target="_blank">Advancement Passport</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Scout Service</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/downloads/BS-Passport-FINAL.pdf" target="_blank">Advancement Passport</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Scout Citizen</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/downloads/BS-Passport-FINAL.pdf" target="_blank">Advancement Passport</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Membership Badge</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/downloads/SS-Eagle-Scout-Passport-FINAL-1.pdf" target="_blank">Advancement Passport</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Explorer Scout</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/downloads/SS-Eagle-Scout-Passport-FINAL-1.pdf" target="_blank">Advancement Passport</a></span><br>
</blockquote><h2>Pathfinder Scout</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/downloads/SS-Eagle-Scout-Passport-FINAL-1.pdf" target="_blank">Advancement Passport</a></span><br>
</blockquote><h2>Outdoorsman Scout</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/downloads/SS-Eagle-Scout-Passport-FINAL-1.pdf" target="_blank">Advancement Passport</a></span><br>
</blockquote><h2>Venturer Scout</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/downloads/SS-Eagle-Scout-Passport-FINAL-1.pdf" target="_blank">Advancement Passport</a></span><br>
</blockquote><h2>Eagle Scout</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/downloads/SS-Eagle-Scout-Passport-FINAL-1.pdf" target="_blank">Advancement Passport</a></span><br>
</blockquote><h2>Camping</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://camping.about.com/blbasics.htm?once=true" target="_blank">Camping Basics</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2> Citizenship in the Community</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.ldb.org/phili2.htm" target="_blank">Government Links</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.mapcentral.ph" target="_blank">Map Central</a></span><br>
<span class="maintext"><a class="genlink" href="https://www.loc.gov/item/92039812/" target="_blank">Philippines: A Country Study</a></span><br>
<span class="maintext"><a class="red" href="http://www.gov.ph/" target="_blank">Philippine Government Portal</a></span><br>
<span class="maintext"><a class="genlink" href="http://en.wikipedia.org/wiki/List_of_Philippine-related_topics#Places_and_Locations" target="_blank">Wikipedia: Phil Places</a></span><br>
<p /><span class="exptext">CIVIC GROUPS</span><br>
<span class="maintext"><a class="genlink" href="http://www.redcross.org.ph/" target="_blank">Philippine National Red Cross</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2> Citizenship in the Home</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.nsc.org/" target="_blank">National Safety Council</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2> Citizenship</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2> Citizenship in the Nation</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.chanrobles.com/index1.htm" target="_blank">Chan Robles Law Library</a></span><br>
<span class="maintext"><a class="genlink" href="https://www.cia.gov/library/publications/resources/the-world-factbook/geos/rp.html" target="_blank">CIA Philippine Fact Sheet</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.ldb.org/phili2.htm" target="_blank">Government Links</a></span><br>
<span class="maintext"><a class="genlink" href="https://www.officialgazette.gov.ph/constitutions/1987-constitution/" target="_blank">Philippine Constitution</a></span><br>
<span class="maintext"><a class="red" href="http://www.gov.ph/" target="_blank">Philippine Government Portal</a></span><br>
<span class="maintext"><a class="genlink" href="https://lawphil.net/judjuris/judjuris.html" target="_blank">Phil. Law & Jurisprudence</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2> Earn Green</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2> Go Green</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2> Grow Green</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Ecology</h2>
<blockquote>
</blockquote><h2>Environment</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.biodiversityhotspots.org/xp/Hotspots/philippines/?showpage=HumanImpacts" target="_blank">Biodiversity Hotspots</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.tryscience.org/csp/csp.html" target="_blank">Citizens for Planet Earth</a></span><br>
<span class="maintext"><a class="genlink" href=" http://www.eepsea.org/" target="_blank">Economy & Environment SEA</a></span><br>
<span class="maintext"><a class="red" href="http://www.gov.ph/cat_environment/default.asp" target="_blank">Gov.PH Environment</a></span><br>
<span class="maintext"><a class="genlink" href="https://lnt.org/learn" target="_blank">Leave No Trace Resources</a></span><br>
<span class="maintext"><a class="genlink" href="http://webmineral.com/" target="_blank">Mineralogy Database</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.pollution.com/" target="_blank">Pollution.Com</a></span><br>
<span class="maintext"><a class="genlink" href="http://mbgnet.mobot.org/fresh/cycle/" target="_blank">Water Cycle</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Emergency Preparedness</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.animatedknots.com/" target="_blank">Animated Knots</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.ropeworks.biz/" target="_blank">Rope Works</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.iveleague.org/s034-aa.html" target="_blank">Preparedness List</a></span><br>
<span class="maintext"><a class="genlink" href="http://ammo.com/articles/surviving-in-the-wild" target="_blank">Wilderness Survival Guide</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Filipino Heritage</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.eaglescorner.com/baybayin" target="_blank">Ating Baybayin</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.islamicart.com/main/calligraphy/index.html" target="_blank">Arabic Calligraphy</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.ayalamuseum.com/" target="_blank">Ayala Museum</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.seasite.niu.edu/tagalog/Literature/tagalog_proverbs_are_called_sala.htm" target="_blank">Philippine Proverbs</a></span><br>
<span class="maintext"><a class="genlink" href="https://www.loc.gov/item/92039812/" target="_blank">Philippines: A Country Study</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.seasite.niu.edu/tagalog/" target="_blank">Tagalog</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.tagalog-dictionary.com/" target="_blank">Tagalog Dictionary</a></span><br>
<span class="maintext"><a class="genlink" href="https://theculturetrip.com/asia/philippines/articles/the-10-best-books-in-philippine-literature/" target="_blank">10 Best Books in Phil Literature</a></span><br>
<span class="maintext"><a class="genlink" href="https://faq.ph/famous-monuments-and-shrines-in-the-philippines-that-you-should-visit/" target="_blank">12 Famous Monuments and Shrines</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>First Aid</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://familydoctor.org/online/famdocen/home.html" target="_blank">Family Doctor.Org</a></span><br>
<span class="maintext"><a class="genlink" href="http://depts.washington.edu/learncpr/" target="_blank">Learn CPR</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.redcross.org.ph/" target="_blank">Philippine National Red Cross</a></span><br>
<span class="maintext"><a class="genlink" href="http://my.webmd.com/" target="_blank">WebMD</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_firstaid.pdf" target="_blank">First Aid</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Lifesaving</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://lifesaving.com/" target="_blank">Lifesaving Resources</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.redcross.org.ph/" target="_blank">Philippine National Red Cross</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Physical Fitness</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://ncadi.samhsa.gov/" target="_blank">Alcohol & Tobacco Abuse</a></span><br>
<span class="maintext"><a class="genlink" href="http://familydoctor.org/handouts/288.html" target="_blank">Diet and Exercise</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.pecentral.org/" target="_blank">PE Central</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.who.int/immunization/en/" target="_blank">WHO on Immunization</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Safety</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="https://www.safety.com/home-safety-checklist/" target="_blank">Home Safety Checklist</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.onlinenewspapers.com/philippi.shtml" target="_blank">Online Newspapers</a></span><br>
<span class="maintext"><a class="genlink" href="https://en.wikipedia.org/wiki/Road_signs_in_the_Philippines" target="_blank">Road Signs</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.safekids.org" target="_blank">Safe Kids Campaign</a></span><br>
<span class="maintext"><a class="genlink" href="http://negordrrm.weebly.com/uploads/1/7/7/4/17742683/schools_checklist_2017.pdf" target="_blank">School Safety Checklist</a></span><br>
<span class="maintext"><a class="genlink" href="https://www.youtube.com/results?search_query=medicine+cabinet" target="_blank">Youtube - Medicine Cabinet</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Soil and Water Conservation</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://wi.essortment.com/foodsoilhumus_rfdg.htm" target="_blank">Uses of Humus</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.humboldt.edu/~ere_dept/marsh/flow1.html" target="_blank">Waste Water Treatment</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Swimming</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.redcross.org.ph/" target="_blank">Philippine National Red Cross</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Tree Farming</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.globaltrees.org/reso_tree.asp?id=34" target="_blank">The Cebu Cinnamon</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.globaltrees.org/reso_tree.asp?id=27" target="_blank">The Philippine Teak</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Weather</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.met.fsu.edu/explores/atmcomp.html" target="_blank">Atmospheric Composition</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>World Brotherhood</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.countryreports.org" target="_blank">Country Reports</a></span><br>
<span class="maintext"><a class="genlink" href="https://www.cia.gov/library/publications/resources/the-world-factbook/index.html" target="_blank">World Factbook - CIA</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.flags.net/" target="_blank">World Flag Database</a></span><br>
<span class="maintext"><a class="genlink" href="https://en.wikipedia.org/wiki/World_Organization_of_the_Scout_Movement" target="_blank">Wikipedia: World Organization of the Scout Movement</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span><p /><span class="exptext">SCOUTING EVENTS</span><br>
<span class="maintext"><a class="genlink" href="https://www.jotajoti.info/" target="_blank">JOTA/JOTI</a></span><br>
<span class="maintext"><a class="genlink" href="https://www.scout.org/youthforum" target="_blank">WOSM Scout Youth Forum</a></span><br>
<p /><span class="exptext">WORLD ORGANIZATIONS</span><br>
<span class="maintext"><a class="genlink" href="http://www.asean.org" target="_blank">Association of South East Asian Nations (ASEAN)</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.un.org" target="_blank">United Nations (UN)</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.scout.org" target="_blank">World Organization of the Scout Movement (WOSM)</a></span><br>
</blockquote><h2>Agriculture</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.birdwatch.ph/" target="_blank">Bird Watch Dot PH</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.da.gov.ph/welcome.html" target="_blank">Department of Agriculture</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.gov.ph/cat_agriculture/default.asp" target="_blank">Gov.PH Agriculture</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.colostate.edu/Depts/CoopExt/4DMG/Pests/pests.htm" target="_blank">Insects and Pests</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.info.com.ph/~philscat/" target="_blank">Philippine-Sino Center for Agricultural Technology</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.crfg.org/tidbits/proptable.html" target="_blank">Plant Propagation Chart</a></span><br>
<span class="maintext"><a class="genlink" href="http://users.rcn.com/jkimball.ma.ultranet/BiologyPages/G/Germination.html" target="_blank">Seed Germination</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Animal Study</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.enchantedlearning.com/coloring/lifecycles.shtml" target="_blank">Animal Life Cycle</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.coml.org/" target="_blank">Census on Marine Life</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.factmonster.com/ce6/sci/A0812450.html" target="_blank">Classifying Animals</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.mapcentral.ph" target="_blank">Map Central</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.euronet.nl/users/janpar/virtual/ocean.html" target="_blank">Virtual Ocean: Microscopic Life</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Archery</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://library.thinkquest.org/27344/heavy.htm?tqskip=1" target="_blank">Archery: Sport of Champions</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.quicks.com/starfram.htm" target="_blank">Quicks: Starting in Archery</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Architecture</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://library.thinkquest.org/10098/index.html?tqskip=1" target="_blank">Architecture through the Ages</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.cupola.com/index.htm" target="_blank">Cupolas Architecture Galleries</a></span><br>
<span class="maintext"><a class="genlink" href="http://web.kyoto-inet.or.jp./org/orion/eng/hst/hist.html" target="_blank">History of Western Architecture</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.islamicart.com/main/architecture/index.html" target="_blank">Islamic Architecture</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.japan-guide.com/e/e2111.html" target="_blank">Japanese Architecture</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.fortunecity.com/victorian/tiffany/126/philarchmain.htm" target="_blank">Philippine Architecture</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Art</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.artgallery.com.ph/" target="_blank">Art Gallery Online</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.explorelearning.com/index.cfm?method=cResource.dspDetail&ResourceID=11" target="_blank">Color - Additive</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.explorelearning.com/index.cfm?method=cResource.dspDetail&ResourceID=49" target="_blank">Color - Subtractive</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.howtodrawmanga.com/tutorial.html" target="_blank">How to Draw Manga</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.polykarbon.com/tutorials" target="_blank">Polykarbon Drawing Tutorial</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.islamicart.com" target="_blank">Islamic Art and Architecture</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.inkart.com/index.html" target="_blank">Michael Halbert Illustrations</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Astronomy</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://members.tripod.com/~AstroKids/" target="_blank">Astronomy for Kids</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.rog.nmm.ac.uk/leaflets/index.html" target="_blank">Astronomy Information Leaflet</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.shatters.net/celestia/" target="_blank">Celestia - 3D Universe</a></span><br>
<span class="maintext"><a class="genlink" href="https://en.wikipedia.org/wiki/Circumpolar_star" target="_blank">Circumpolar Stars</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.astro.wisc.edu/~dolan/constellations/" target="_blank">Constellation and Their Stars</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.stargazing.net/david/constel/brightstars.html" target="_blank">First Magnitude Stars</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.explorelearning.com/index.cfm?method=cResource.dspDetail&ResourceID=36" target="_blank">Orbit Simulator</a></span><br>
<span class="maintext"><a class="genlink" href="http://seds.lpl.arizona.edu/nineplanets/nineplanets/nineplanets.html" target="_blank">Our Solar System</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.astro.wisc.edu/~dolan/constellations" target="_blank">Stars and Constellations</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.tryscience.org/" target="_blank">Try Science</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.solarviews.com/eng/homepage.htm" target="_blank">View of the Solar System</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.scienceandart.com/0galleryzodiac.htm" target="_blank">Zodiac Constellation</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Athletics</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Aviation</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.allstar.fiu.edu/aerojava/" target="_blank">ALLSTaR Network</a></span><br>
<span class="maintext"><a class="genlink" href="http://aviation-safety.net/database/country/RP.shtml" target="_blank">Aviation Safety Network</a></span><br>
<span class="maintext"><a class="genlink" href="http://library.thinkquest.org/20174/present/modern_principles_of_flight.htm?tqskip=1" target="_blank">Modern Principles of Flight</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.soton.ac.uk/~scp93ch/morse/index.html?http://www.soton.ac.uk/~scp93ch/morse/alphabet.html" target="_blank">Phonetic Alphabet Chart</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.explorelearning.com/index.cfm?method=cResource.dspDetail&ResourceID=24" target="_blank">Plane Wing Simulation</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.tryscience.org/experiments/experiments_begin.html?wingit" target="_blank">Try Science Experiment: Wingin It</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Automobiling</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.misterfixit.com/autorepr.htm" target="_blank">Auto Repair Page</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.dmv.ca.gov/pubs/hdbk/driver_handbook_toc.htm" target="_blank">California Driver Handbook</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.innerauto.com/" target="_blank">Inner Auto Parts</a></span><br>
<span class="maintext"><a class="genlink" href="http://hyperphysics.phy-astr.gsu.edu/hbase/crstp.html" target="_blank">Stopping Distance for Autos</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.lto.gov.ph/" target="_blank">The Land Transportation Office</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Beekeeping</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://gears.tucson.ars.ag.gov" target="_blank">Bee Research Center</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.beeworks.com" target="_blank">Bee Works</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.beemaster.com/honeybee/beehome.htm" target="_blank">Beekeeping Course</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Bookbinding</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.aboutbookbinding.com/" target="_blank">About Bookbinding</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.cs.uiowa.edu/~jones/book" target="_blank">Bookbinding Tutorial</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Boating</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.boatingsafety.com/" target="_blank">Boating Safety</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.scouting.org/pubs/aquatics/index2.html" target="_blank">BSA Safe Swim Defense/Safety Afloat Online Training</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.firstalert.com/home_safety/fire_extinguishers/facts.htm" target="_blank">Fire and Extinguishers</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.learn-orienteering.org/old/" target="_blank">How to Use a Compass</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.bsatroop780.org/skills/Orienteering.htm" target="_blank">Orienteering - BSA Troop 780</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.uscgboating.org/" target="_blank">USCG Boating Safety</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/notes_compass.pdf" target="_blank">Compass Reading</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Basketry</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.kstrom.net/isk/art/basket/baskmenu.html" target="_blank">Native Basketry</a></span><br>
<span class="maintext"><a class="genlink" href="http://pinebaskets.tripod.com" target="_blank">Pegs Basketry</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Birdstudy</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.birdwatch.ph/" target="_blank">Bird Watch Dot PH</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.geocities.com/yosemite/3712/endbirds.html" target="_blank">Endangered Birds</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.peregrinefund.org" target="_blank">Peregrine Fund</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.pawb.gov.ph/" target="_blank">Protected Area and Wildlife</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Botany</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.botany.com" target="_blank">Botany.Com</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.alienexplorer.com/ecology/topic3.html" target="_blank">Photosynthesis</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.rbg.ca/cbcn/en/kids/kid_anatomy.htm" target="_blank">Plant Anatomy</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Barbering</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.barberpole.com" target="_blank">Barber Pole</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Blacksmithing</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://engineeringhut.blogspot.com/2010/10/forging-operations.html" target="_blank">Forging Operations</a></span><br>
<span class="maintext"><a class="genlink" href="https://www.youtube.com/watch?v=d7E7Gl1K4aA" target="_blank">Youtube: Forging Tent Stakes</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Business</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://esl.about.com/library/weekly/aa041399.htm" target="_blank">Business Letter Writing</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.eresumewriting.com" target="_blank">eResume Writing</a></span><br>
<span class="maintext"><a class="genlink" href="http://mathforum.org/dr.math/faq/faq.fractions.html" target="_blank">Fractions-Decimals-Percentages</a></span><br>
<span class="maintext"><a class="genlink" href="http://mathforum.org/dr.math/faq/faq.interest.html" target="_blank">Loans and Interest</a></span><br>
<span class="maintext"><a class="genlink" href="http://pitmanshorthand.homestead.com/" target="_blank">Pitman Shorthand</a></span><br>
<span class="maintext"><a class="genlink" href="http://owl.english.purdue.edu/handouts/pw/" target="_blank">Professional Writing</a></span><br>
<span class="maintext"><a class="genlink" href="http://writing.colostate.edu/guides/documents/resume/" target="_blank">Resume Writing</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Carpentry</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Computers</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://ferretronix.com/march/computer_cards/" target="_blank">Computer Cards (Hollerith Tabulator)</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.computerhistory.org" target="_blank">Computer History Center</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.computer.org/history/" target="_blank">History of Computing - IEEE</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Cooking</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.cjnetworks.com/~kwood/scouting/menus/cooking.html" target="_blank">Camp Cooking</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.cookingtogether.com/" target="_blank">Chinese Cooking</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/ll_foodsafety.pdf" target="_blank">Food Safety</a></span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Cycling</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.exploratorium.edu/cycling" target="_blank">Science of Cycling</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.usacycling.org/" target="_blank">USA Cycling Online</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Crop Production</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.da.gov.ph/tips/techno_guides.html" target="_blank">Farming Tips</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Coconut Growing</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.coconut.com/" target="_blank">Coconut.Com</a></span><br>
<span class="maintext"><a class="genlink" href="http://ambergriscaye.com/cocopalms/" target="_blank">Coconut General Information</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.foodmarketexchange.com/datacenter/product/fruit/coconut/dc_pi_ft_coconut.html" target="_blank">Food Market Place: Coconuts</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.sarawak.com.my/borneo_lit/pest/page07.html" target="_blank">Pest of Coconut and Oil Palms</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.ucap.org.ph/" target="_blank">United Coconut Association</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Chemistry</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.ilpi.com/safety/" target="_blank">Chemistry Lab Safety</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.explorelearning.com" target="_blank">Explore Learning</a></span><br>
<span class="maintext"><a class="genlink" href="http://home.howstuffworks.com/question99.htm" target="_blank">How Water Softner Works</a></span><br>
<span class="maintext"><a class="genlink" href="http://water.me.vccs.edu/concepts/oxycycle.html" target="_blank">Oxygen Cycle</a></span><br>
<span class="maintext"><a class="genlink" href="http://search.yehey.com/categories.aspx?c=736" target="_blank">Philippine Universities</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.woodcentral.com/bparticles/rust.shtml" target="_blank">Protecting Metal Hand Tools</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.sciencebob.com/" target="_blank">Science Bob</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.tryscience.org/" target="_blank">Try Science</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Dairying</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.gotmilk.com" target="_blank">Got Milk?</a></span><br>
<span class="maintext"><a class="genlink" href="http://nda.da.gov.ph/index.htm" target="_blank">National Dairy Authority</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Drafting</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.hms.havre.k12.mt.us/hagen/tools/5/index.html" target="_blank">Drafting Notes</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.tech.purdue.edu/cg/courses/tg217/217_lay.html" target="_blank">Drawing Systems</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Dramatics</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.gpc.edu/~lawowl/handouts/analyzing-a-play.pdf#search='Elements%20of%20a%20Play'" target="_blank">Analyzing a Play (PDF)</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.theatrehistory.com/" target="_blank">Theatre History</a></span><br>
<span class="maintext"><a class="genlink" href="http://nv.essortment.com/makeuptheatric_rllw.htm" target="_blank">Theatrical Make-Up Application</a></span><br>
</blockquote><h2>Duck Raising</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.metzerfarms.com/" target="_blank">Duck and Goose Hatchery</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.duckhealth.com" target="_blank">Duck Care</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Electricity</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.pcguide.com/ref/power/ext/basicsACDC-c.html" target="_blank">Alternating and Direct Current</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.sciencebob.com/experiments/electromagnet.html" target="_blank">Build an Electromagnet</a></span><br>
<span class="maintext"><a class="genlink" href="http://scitec.uwichill.edu.bb/cmp/online/P10D/help/splash/index.htm" target="_blank">Electricity and Magnetism</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.explorelearning.com/index.cfm?method=cResource.dspResourcesForCourse&CourseID=334" target="_blank">Explore Learning</a></span><br>
<span class="maintext"><a class="genlink" href="http://americanhistory.si.edu/csr/powering/generate/gnmain.htm" target="_blank">Generating Electricity</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.howstuffworks.com/" target="_blank">How Stuff Works</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Electronics</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.explorelearning.com" target="_blank">Explore Learning</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.talkingelectronics.com/projects/5-Projects/Projects16.html" target="_blank">Flip-Flop Circuit</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.aaroncake.net/electronics/solder.htm" target="_blank">How to Solder</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.technologystudent.com/elec1/transis1.htm" target="_blank">Transistor Basic</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.tryscience.org/" target="_blank">Try Science</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.howstuffworks.com/" target="_blank">How Stuff Works</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Engineering</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.explorelearning.com" target="_blank">Explore Learning</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.yehey.com/search/categories.aspx?c=736" target="_blank">Philippine Universities</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.tryscience.org/" target="_blank">Try Science</a></span><br>
<span class="maintext"><a class="genlink" href="http://dir.yahoo.com/Science/Engineering" target="_blank">Yahoo! Engineering</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Farm Management</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.da.gov.ph/tips/techno_guides.html" target="_blank">Farming Tips</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.almanac.com" target="_blank">Old Farmers Almanac</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.openacademy.ph/" target="_blank">Pinoy Farmers Internet</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.ibiblio.org/farming-connection" target="_blank">Sustainable Farming Connection</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Fishing</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.getlostmagazine.com/features/1999/9909fishclean/fishclean.html" target="_blank">Fish Cleaning Guide</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Forestry</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.psdn.org.ph/denr/fmb/fmb2.htm" target="_blank">Forest Management Bureau</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.almanac.com" target="_blank">Old Farmers Almanac</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Fruit Cultivation</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.da.gov.ph/tips/techno_guides.html" target="_blank">Farming Tips</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.tfrec.wsu.edu" target="_blank">Tree Fruit</a></span><br>
<span class="maintext"><a class="genlink" href="http://home.hawaii.rr.com/tropicalfruit/" target="_blank">Tropical Fruit</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Firemanship</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.arkfireprevention.org" target="_blank">Arkansas Fire Prevention</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.bfponline.com/" target="_blank">Bureau of Fire Protection</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.firstalert.com/home_safety/fire_extinguishers/facts.htm" target="_blank">Fire and Extinguishers</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.ehs.utah.edu/firesafe/flame.htm" target="_blank">Handling of Flammable Liquids</a></span><br>
<span class="maintext"><a class="genlink" href="http://www-ehs.ucsd.edu/fire/firebk/fireflam.htm" target="_blank">Storage of Flammable Liquids</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.geocities.com/tac_bfp" target="_blank">Tacloban Central Fire Station</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Fish Culture</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Food Processing</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Gardening</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.bhglive.com" target="_blank">Better Home and Garden</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.gardeners.com/gardening/default.asp" target="_blank">Gardeners Supply Company</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.greenliving.org" target="_blank">Green Living Center</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.colostate.edu/Depts/CoopExt/4DMG/Pests/pests.htm" target="_blank">Insects and Pests</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.almanac.com/garden/" target="_blank">Old Farmers Almanac</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.gardenersnet.com/veggies.htm" target="_blank">Vegetable Gardening Info</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Handicraft</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Hobbies and Collection</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://coins.about.com/library/weekly/aa052300a.htm" target="_blank">Beginning Coin Collection</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.islamicart.com/main/coins/index.html" target="_blank">Islamic Coins</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.geocities.com/Yosemite/Trails/4936/" target="_blank">Italian Virtual Patch Collection</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.sossi.org/" target="_blank">SOSSI</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.worldcoingallery.com/" target="_blank">World Coin Gallery</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Home Repairs</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.epemag.wimborne.co.uk/solderfaq.htm" target="_blank">Basic Soldering Guide</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.bhglive.com" target="_blank">Better Home and Garden</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.hammerzone.com/" target="_blank">HammerZone.Com</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.hometime.com" target="_blank">Home Time Projects</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.howstuffworks.com" target="_blank">How Stuff Works</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Hiking</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.backpacker.com/survival/" target="_blank">Backpacker Survival Skills</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.backpacking.net/beginner.html" target="_blank">Backpacking and Hiking for Beginners</a></span><br>
<span class="maintext"><a class="genlink" href="https://www.nerdfitness.com/blog/2011/09/07/hiking/" target="_blank">Beginners Guide to Hiking</a></span><br>
<span class="maintext"><a class="genlink" href="http://andrewskurka.com/2011/train-for-a-long-distance-hike/" target="_blank">Train for Long Distance Hike</a></span><br>
<span class="maintext"><a class="genlink" href="http://ammo.com/articles/surviving-in-the-wild" target="_blank">Wilderness Survival</a></span><br>
</blockquote><h2>Hog Raising</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.da.gov.ph/agribusiness/hog.html" target="_blank">DA Industry Report</a></span><br>
<span class="maintext"><a class="genlink" href="http://itcph.da.gov.ph/" target="_blank">International Training Center for Pig Husbandry</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Horsemanship</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.beva.org.uk" target="_blank">British Equine Vet Association</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.thehorse.com" target="_blank">Horse Interactive</a></span><br>
<span class="maintext"><a class="genlink" href="http://netvet.wustl.edu/horses.htm" target="_blank">NetVet: Horses</a></span><br>
<p /><span class="exptext">DISEASES</span><br>
<span class="maintext"><a class="genlink" href="http://www.aphis.usda.gov/vs/eia/eia.html" target="_blank">Equine Infectious Anemia</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.ag.state.co.us/animals/livestock_disease/vs.html" target="_blank">Vesicular Stomatitis</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Interpreting</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://babelfish.altavista.com" target="_blank">Altavista Babelfish</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.yourdictionary.com/languages.html" target="_blank">Language Dictionaries</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Insect Study</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.bugbios.com/index.html" target="_blank">Bugbios</a></span><br>
<span class="maintext"><a class="genlink" href="http://129.186.120.14/msie.html" target="_blank">Insect Zoo Cam</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.butterflyschool.org/teacher/raising.html" target="_blank">Raising Butterflies and Moths</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Journalism</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://abovethefold.homestead.com/A1.html" target="_blank">Inkshots: Photojournalism</a></span><br>
<span class="maintext"><a class="genlink" href="http://mindy.mcadams.com/jaccess" target="_blank">Journalism Access</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.onlinenewspapers.com/" target="_blank">Online Newspapers</a></span><br>
<span class="maintext"><a class="genlink" href="http://link.bubl.ac.uk/writing/" target="_blank">Online Resources</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.yehey.com/search/categories.aspx?c=903" target="_blank">Philippine Newspapers</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.typography-1st.com/typo/txt-lay.htm" target="_blank">Typography and Layout</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Livestock Raising</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.ldc.da.gov.ph/" target="_blank">Livestock Development Council</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.naturalfamilyhome.com/livestock.html" target="_blank">Raising Small Livestock</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Leathercraft</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://iilg.org/" target="_blank">Internet Leathercrafters Guild</a></span><br>
<span class="maintext"><a class="genlink" href="http://moas.atlantia.org/topics/leat.htm" target="_blank">Leatherwork Links</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Machine Shop Practice</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Marksmanship</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.huntingsociety.org/nevers.html" target="_blank">Firearms Safety Society</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Masonry</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://solidrockmasonry.com/diy/" target="_blank">DIY Masonry Heaters & Building Codes</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.maconline.org/" target="_blank">Masonry Advisory Council</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.masonryforlife.com/HowToBasics.htm" target="_blank">Masonry Basics</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Metal Work</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.artmetal.com/village/welcome/index.html" target="_blank">ArtMetal Village</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.islamicart.com/main/architecture/metal1.html" target="_blank">Islamic Metal Work</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Music</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.gopinoy.com/entertainment/soundfactory" target="_blank">Sound Factory</a></span><br>
</blockquote><h2>Nature Lore</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.bwf.org/" target="_blank">Babilonia Wilner Foundation</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.bugbios.com/index.html" target="_blank">Bugbios</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.geocities.com/yosemite/3712/endbirds.html" target="_blank">Endangered Birds</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.haribon.org.ph/" target="_blank">Haribon Foundation</a></span><br>
<span class="maintext"><a class="genlink" href="http://129.186.120.14/msie.html" target="_blank">Insect Zoo Cam</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.cftech.com/BrainBank/OTHERREFERENCE/ANIMALWORLD/OrderMammals.html" target="_blank">Orders of Mammals</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.peregrinefund.org" target="_blank">Peregrine Fund</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Navigation</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Pathfinding</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.scoutingresources.org.uk/codes/index.html" target="_blank">Code & Signs: UK Scouting Resources</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.mapcentral.ph" target="_blank">Map Central</a></span><br>
<span class="maintext"><a class="genlink" href="http://en.wikipedia.org/wiki/Cities_of_the_Philippines" target="_blank">Wikipedia: Philippine Cities</a></span><br>
<span class="maintext"><a class="genlink" href="http://lrt.yehey.com" target="_blank">Yehey! Rail Transit Guide</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Pet Care</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.cftech.com/BrainBank/OTHERREFERENCE/ANIMALWORLD/AnimFirstAid.html" target="_blank">Animal First Aid</a></span><br>
<span class="maintext"><a class="genlink" href="http://netvet.wustl.edu" target="_blank">NetVet Veterinary Resources</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.vin.com/" target="_blank">Veterinary Inforamtion Network</a></span><br>
<span class="maintext"><a class="genlink" href="http://pets.yahoo.com/pets/" target="_blank">Yahoo! Pets</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Plumbing</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://hometime.com/projects/plmbelec.htm" target="_blank">HomeTime: Plumbing</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.acwd.org/doingbusiness-watermeter.html" target="_blank">Reading Water Meter</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Photography</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.flickr.com/groups/digitalps/" target="_blank">Digital Photography School</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.fodors.com/focus" target="_blank">Focus on Photography</a></span><br>
<span class="maintext"><a class="genlink" href="http://abovethefold.homestead.com/A1.html" target="_blank">Photojournalism - Inkshots</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.digitaltruth.com" target="_blank">Photosource: Film Developing</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.retrato.com.ph/" target="_blank">Retrato: Photo Library</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.kodak.com/US/en/nav/takingPics.shtml" target="_blank">Taking Great Pictures - Kodak</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Painting</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.explorelearning.com/index.cfm?method=cResource.dspDetail&ResourceID=11" target="_blank">Color - Additive</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.explorelearning.com/index.cfm?method=cResource.dspDetail&ResourceID=49" target="_blank">Color - Subtractive</a></span><br>
</blockquote><h2>Personal Health</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="https://medlineplus.gov/guidetogoodposture.html" target="_blank">Guide to Good Posture</a></span><br>
<span class="maintext"><a class="genlink" href="https://www.cdc.gov/handwashing/index.html" target="_blank">Handwashing Save Lives</a></span><br>
<span class="maintext"><a class="genlink" href="https://www.zehnderamerica.com/how-bedroom-co2-levels-impact-restful-sleep/" target="_blank">How Bedroom CO2 Impact Sleep</a></span><br>
<span class="maintext"><a class="genlink" href="https://elliottphysicaltherapy.com/importance-proper-breathing-overall-health/" target="_blank">Importance of Proper Breathing</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.who.int/immunization/en/" target="_blank">WHO on Immunization</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.who.int/" target="_blank">World Health Organization</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Pigeon Raising</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Pioneering</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.animatedknots.com/" target="_blank">Animated Knots</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.scoutingresources.org.uk/knots/index.html" target="_blank">Knots: UK Scouting Resources</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.scouting.org.za/resources/pioneering/" target="_blank">Pioneering Resources</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.ropeworks.biz/" target="_blank">Rope Works</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Pottery</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.andsarahlaughed.com" target="_blank">Pottery Everyday</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Poultry Raising</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Public Health</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Public Speaking</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.geocities.com/Area51/Lair/8462/speechmain.html" target="_blank">Matts Speech Writer</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Printing</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.execpc.com/~bosshard/printing/letrprss/basictools.html" target="_blank">Bosshards Printing Primer</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.greendolphinpress.com/letterpress-faq.html" target="_blank">Letterpress FAQ</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.matisse.com.au/paintingtechniques/SilkScreenPrinting.html" target="_blank">Silk Screen Printing</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Rabbit Raising</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.gov.pe.ca/photos/original/4h_rabbit_RG.pdf" target="_blank">4H Rabbit Manual</a></span><br>
<span class="maintext"><a class="genlink" href="http://florida4h.org/projects/rabbits/MarketRabbits/Files/MarketRabbitRecord.pdf" target="_blank">4H Rabbit Market Record</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.debmark.com/rabbits/rabbits.htm" target="_blank">DebMark Rabbit Resource</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.rabbitweb.net/" target="_blank">Rabbit Web</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Ropework</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.animatedknots.com/" target="_blank">Animated Knots</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.scoutingresources.org.uk/knots/index.html" target="_blank">Knots: UK Scouting Resources</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.ropeworks.biz//" target="_blank">Rope Works</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Radio</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.arrl.org/FandES/ead/scouthbk/" target="_blank">ARRL Scout Radio Handbook</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.middelkoop7.myweb.nl/" target="_blank">Jamboree-On-The-Air</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.soton.ac.uk/~scp93ch/morse/index.html?http://www.soton.ac.uk/~scp93ch/morse/trans.html" target="_blank">Morse Code Translator</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.scoutingresources.org.uk/codes/codes_morse.html" target="_blank">Morse Code: UK Scouting Resources</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.copper.com/codes.html" target="_blank">Radio Codes</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.appliancepartspros.com/how-to-solder.aspx" target="_blank">Solder, How to</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.epemag.wimborne.co.uk/solderfaq.htm" target="_blank">Soldering: Basic Guide</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.elexp.com/t_solder.htm" target="_blank">Soldering: Tips</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Reading</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.english.uiuc.edu/cws/wworkshop/bibliostyles.htm" target="_blank">Bibliography Style Handbook</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.bartleby.com/" target="_blank">Bartleby: Great Books Online</a></span><br>
<span class="maintext"><a class="genlink" href="http://nerdycarabao.com/" target="_blank">Nerdy Carabao eBookstore</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.onlinenewspapers.com/" target="_blank">Online Newspapers</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Reptile and Amphibian Study</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.embl-heidelberg.de/~uetz/LivingReptiles.html" target="_blank">Reptile Database</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.geocities.com/RainForest/Vines/1275" target="_blank">Yanivs Herpetological Handbook</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Rizal Lore</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.univie.ac.at/Voelkerkunde/apsis/aufi/fblumen.htm" target="_blank">Blumentritt Friendship</a></span><br>
<span class="maintext"><a class="genlink" href="http://home.t-online.de/home/m.dg.k/frontpage.htm" target="_blank">German Heritage Trail</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.univie.ac.at/Voelkerkunde/apsis/aufi/jorizal.htm" target="_blank">Jose Rizal (Austria)</a></span><br>
<span class="maintext"><a class="genlink" href="http://pages.prodigy.net/manila_girl/rizal" target="_blank">Rizaliana</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.univie.ac.at/Voelkerkunde/apsis/aufi/vtr/vtr.htm" target="_blank">Virtual Travel of Rizal</a></span><br>
<span class="maintext"><a class="genlink" href="http://dir.yahoo.com/Arts/Crafts/Scrapbooking/" target="_blank">Yahoo Category: Scrapbooking</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span><p /><span class="exptext">RIZAL NOVELS</span><br>
<span class="maintext"><a class="genlink" href="http://www.viloria.com/elfilibusterismo/" target="_blank">El Filibusterismo</a></span><br>
</blockquote><h2>Scholarship</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Sculpture</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.sculptor.org" target="_blank">Sculpture.Org</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Salesmanship</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Seamanship</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.learn-orienteering.org/old/" target="_blank">How to Use a Compass</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.ropeworks.biz//" target="_blank">Rope Works</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.sailnet.com/collections/seamanship/" target="_blank">SailNet Seamanship</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Signaling</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.arrl.org/FandES/ead/scouthbk/" target="_blank">ARRL Scout Radio Handbook</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.soton.ac.uk/~scp93ch/morse/index.html?http://www.soton.ac.uk/~scp93ch/morse/trans.html" target="_blank">Morse Code Translator</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.scoutingresources.org.uk/codes/codes_morse.html" target="_blank">More Code: UK Scouting Resources</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.morsehistoricsite.org/" target="_blank">Samuel Morse Historic Site</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Snorkeling</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://scuba.about.com/cs/snorkeling/" target="_blank">Snorkeling Resources</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Surveying</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://surveying.mentabolism.org/" target="_blank">Land Surveying and Geomatics</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.ultranet.com/~deeds/survey.htm" target="_blank">Surveying Terms</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.surveyhistory.org/" target="_blank">Virtual Museum of Surveying</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Tailoring</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.secretsof.com/embroiderytips/index.html" target="_blank">Machine Embroidery</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Teamsports</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.geocities.com/sissio/" target="_blank">Physical Education Page</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.fiba.com" target="_blank">International Basketball Federation</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.olympic.org" target="_blank">International Olympic Committee</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.usta.com/index.html" target="_blank">US Tennis Association</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Wildlife Conservation</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.bwf.org/" target="_blank">Babilonia Wilner Foundation</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.biodiversityhotspots.org/xp/Hotspots/philippines/?showpage=HumanImpacts" target="_blank">Biodiversity Hotspots</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.tryscience.org/csp/csp.html" target="_blank">Citizens for Planet Earth</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.haribon.org.ph" target="_blank">Haribon Foundation</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.peregrinefund.org" target="_blank">Peregrine Fund</a></span><br>
<span class="maintext"><a class="genlink" href="http://en.wikipedia.org/wiki/Plant_succession" target="_blank">Plant Succession</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Wood Carving</h2>
<blockquote>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>Wood Work</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://www.islamicart.com/main/architecture/wood.html" target="_blank">Islamic Wood Works</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/ws.php">Merit Badge Worksheet</a></span></blockquote><h2>World Wide Web</h2>
<blockquote>
<span class="maintext"><a class="genlink" href="http://en.wikibooks.org/wiki/Web_Design:Learning_Basic_HTML_and_CSS" target="_blank">Basic HTML and CSS</a></span><br>
<span class="maintext"><a class="genlink" href="http://writing.colostate.edu/guides/documents/email/" target="_blank">E-mail Writing</a></span><br>
<span class="maintext"><a class="genlink" href="http://en.wikipedia.org/wiki/Hacker_ethic" target="_blank">Hacker Ethic</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.computerhistory.org/exhibits/internet_history/" target="_blank">History of the Internet</a></span><br>
<span class="maintext"><a class="genlink" href="http://www.joti.org/" target="_blank">Jamboree on the Internet</a></span><br>
<span class="maintext"><a class="genlink" href="http://en.wikipedia.org/wiki/Netiquette" target="_blank">Netiquette</a></span><br>
<p /><span class="exptext">LOCAL LINKS</span><br>
<span class="maintext"><a class="genlink" href="/pub/pdf/proposal_wwwmb.pdf" target="_blank">PDF Version</a></span><br>
</blockquote>                    </p>
                    <p>&nbsp; </p>
                  </div>
                  <!-- InstanceEndEditable --></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellpadding="3" cellspacing="1" class="tablebordertopbot">
          <tr>
            <td width="50%">Copyright &copy; 2020, Merit Badge Center, Philippines<br />
              Since August 4, 1999 - Fourth Edition September 30, 2003 </td>
            <td width="50%" align="right" background="/htm/pub/mbcpterms.php" class="fineprint"><a href="/htm/pub/mbcpterms.php" class="stealth">Terms, Conditions, and Information</a> </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellspacing="1" cellpadding="3">
          <tr>
            <td>
				
			</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
