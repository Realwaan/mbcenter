<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/mbcptemplate2007_2.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="fb:app_id" content="167734213309548"/>
<link rel="shortcut icon" href="/img/mbcp.ico" />
<script type="text/JavaScript" src="/script/genscripts2007.js"></script>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines :: Advancement Ranks</title>
<!-- InstanceEndEditable -->
<link href="/css/mainstyle2007.css" rel="stylesheet" type="text/css" />
<!-- InstanceBeginEditable name="head" --><!-- InstanceEndEditable -->
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=204511906280785";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td bgcolor="#FFFFFF"><img src="/img/banner_main_2007.jpg" alt="Merit Badge Center, Philippines" width="768" height="86" /></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="25%" valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
              </tr>         
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/advancement.php" class="mainlink">Advancement Ranks</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/" class="mainlink" >Merit Badges (Alphabetical)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbcitizenrequired.php" class="mainlink" >Merit Badges (Citizen Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbeaglerequired.php" class="mainlink" >Merit Badges (Eagle Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbelectives.php" class="mainlink" >Merit Badges (Electives)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/ws.php" class="mainlink" >Advancement Worksheets</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/contactus/" class="mainlink" >Contact Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/aboutus.php" class="mainlink" >About Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/sitehelp.php" class="mainlink" >Help</a></td>
              </tr>
			  <tr>
			  	<td class="maintext">&nbsp;</td>
			  </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" -->
                        <p>&nbsp;</p>
            <!-- InstanceEndEditable -->            
              </td>
              <td valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="5">
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><!-- InstanceBeginEditable name="MainBody" --> 
                  <h1>Advancement Rank</h1>
                  <p class="maintext">These are the advancement ranks for both 
                    the Boy Scout and Senior Scout programs of the Boy Scouts 
                    of the Philippines. Boy Scouting is <strong>not a pre-requisite</strong> 
                    for Senior Scouting. These are now based on the revised Passport Advancement Scheme as of 2019 for Boy Scout Program and 2025 for Senior Scout Program.</p>
                  <p class="maintext">Learn the basic idea of the <a href="/htm/pub/advprocess.php">Scout
                    Advancement Process</a>. </p>
                  <blockquote>
                    <p><span class="h2">Boy Scout Program</span><br />
                      <strong><span class="maintext"><a href="/downloads/BS-Passport-FINAL.pdf">Download 
                      the Scout Citizen Advancement Passport</a></span></strong><br />
            </p>
                    <ul class="maintext">
                      <li><a href="ranks.php?rnk=pp-bsmembership">Membership</a></li>
                      <li><a href="ranks.php?rnk=pp-tenderfoot">Tenderfoot Scout</a></li>
                      <li><a href="ranks.php?rnk=pp-secondclass">Second Class Scout</a></li>
                      <li><a href="ranks.php?rnk=pp-firstclass">First Class Scout</a></li>
                      <li><a href="ranks.php?rnk=pp-service">Scout Service</a></li>
                      <li><a href="ranks.php?rnk=pp-citizen">Scout Citizen</a>                    </li>
                    </ul>
                    <p><span class="h2">Senior Scout Program</span><br />
                      <strong><span class="maintext"><a href="../downloads/2025-Updated-Senior-Scout-Passport.pdf">Download the My Trail to Eagle Scout Advancement Passport</a></span></strong></p>
                    <ul class="maintext">
                      <li><a href="ranks.php?rnk=pp-membership">Membership</a></li>
                      <li><a href="ranks.php?rnk=pp-explorer">Explorer Scout</a></li>
                      <li><a href="ranks.php?rnk=pp-pathfinder">Pathfinder Scout</a></li>
                      <li><a href="ranks.php?rnk=pp-outdoor">Outdoor Scout</a></li>
                      <li><a href="ranks.php?rnk=pp-venturer">Venturer Scout</a></li>
                      <li><a href="ranks.php?rnk=pp-eagle">Eagle Scout</a></li></ul>
                  </blockquote>
                  <h2>Eagle Scout Anahaw Award                  </h2>
                  <ol>
                    <li class="maintext">Bronze Anahaw. Earning 6 additional <a href="meritbadgelist.php">Merit Badges</a> after earning the Eagle Scout.</li>
                    <li class="maintext">Silver Anahaw. Earning 6 additional <a href="meritbadgelist.php">Merit Badges</a> after earning the Bronze Anahaw.</li>
                    <li class="maintext">Gold Anahaw. Earning 6 additional <a href="meritbadgelist.php">Merit Badges</a> after earning the Silver Anahaw.</li>
                  </ol>
                  <p class="maintext">&nbsp;</p>
                  <!-- InstanceEndEditable --></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellpadding="3" cellspacing="1" class="tablebordertopbot">
          <tr>
            <td width="50%">Copyright &copy; 2020, Merit Badge Center, Philippines<br />
              Since August 4, 1999 - Fourth Edition September 30, 2003 </td>
            <td width="50%" align="right" background="/htm/pub/mbcpterms.php" class="fineprint"><a href="/htm/pub/mbcpterms.php" class="stealth">Terms, Conditions, and Information</a> </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellspacing="1" cellpadding="3">
          <tr>
            <td>
				
			</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
