<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/mbcptemplate2007_2.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="fb:app_id" content="167734213309548"/>
<link rel="shortcut icon" href="/img/mbcp.ico" />
<script type="text/JavaScript" src="/script/genscripts2007.js"></script>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines :: Submit a Site</title>
<!-- InstanceEndEditable -->
<link href="/css/mainstyle2007.css" rel="stylesheet" type="text/css" />
<!-- InstanceBeginEditable name="head" --> 
<style type="text/css">
<!--
a.biglink {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #006600;
	text-decoration: none;
}
a.biglink:hover {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #006600;
	text-decoration: none;
}
.bluetext {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000066;
	font-weight: bold;
}
-->
</style><!-- InstanceEndEditable -->
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=204511906280785";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td bgcolor="#FFFFFF"><img src="/img/banner_main_2007.jpg" alt="Merit Badge Center, Philippines" width="768" height="86" /></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="25%" valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
              </tr>         
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/advancement.php" class="mainlink">Advancement Ranks</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/" class="mainlink" >Merit Badges (Alphabetical)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbcitizenrequired.php" class="mainlink" >Merit Badges (Citizen Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbeaglerequired.php" class="mainlink" >Merit Badges (Eagle Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbelectives.php" class="mainlink" >Merit Badges (Electives)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/ws.php" class="mainlink" >Advancement Worksheets</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/contactus/" class="mainlink" >Contact Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/aboutus.php" class="mainlink" >About Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/sitehelp.php" class="mainlink" >Help</a></td>
              </tr>
			  <tr>
			  	<td class="maintext">&nbsp;</td>
			  </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" --> 
            <p class="maintext">&nbsp;</p>
            <!-- InstanceEndEditable -->            
              </td>
              <td valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="5">
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><!-- InstanceBeginEditable name="MainBody" --> 
              <h1>Frequently Asked Questions </h1>
              <blockquote> 
                <p class="maintext"><span class="bluetext"><strong>Are you an official Boy Scouts of the Philippines (BSP) website?</strong></span><strong><br />
                </strong>No.</p>
                <p class="maintext"><strong class="bluetext">Are you endorsed by the BSP?</strong><br />
                  No.</p>
                <p class="maintext"><span class="bluetext"><strong>You are  one of the sites linked on the BSP website, isn't that a sign of endorsement? <br />
                </strong></span>Our inclusion in the affiliate list of the <a href="http://www.phiscout.org/" target="_blank">official BSP website</a> does not mean recognition or endorsement. </p>
                <p><span class="bluetext"><strong>How much acceptance does the materials on the website receive from the BSP? </strong></span><span class="maintext"><strong><br />
                </strong>Almost all the documents and materials on the website has been used by the local councils and districts of the BSP. Patrol Leader Training Courses (PLTC) and Basic Training Courses (BTC) in the country have includes materials from the website as part of a CD-ROM distribution.<strong><br />
                  <br />
                </strong></span> <span class="bluetext"><strong>Do you sell Boy Scout merchandise?</strong></span><strong><br />
                  </strong><span class="maintext">No. Direct
                  all inquiries to the <a href="http://www.phiscout.org" target="_blank">official
                  BSP website</a>.</span></p>
                <p class="maintext"><strong class="bluetext">How do I link to your site?</strong><br />
                Link to <a href="http://www.meritbadge.org.ph" target="_blank">www.MeritBadge.org.ph</a>. If interested, you may also use
                  our <a href="/htm/linkingtombcp.php">banner ads</a> or our <a href="/htm/mbquicklink.php">Merit
                  Badge Quick link</a>. </p>
                <p class="maintext"><span class="bluetext"><strong>How can I help the Merit Badge Center?</strong></span><strong><br />
                </strong>There are many ways of helping.</p>
                <ul class="maintext">
                  <li>Spread the word about the Merit Badge Center within your
                    institution.</li>
                  <li>If you have your own website, you can provide a link to
                    the Merit Badge Center. <em>Doing so however does not guarantee
                    reciprocity</em>.</li>
                  <li>If your website offers assistance in earning advancement
                    ranks or merit badges, <a href="/htm/submitasite.php">submit
                    your site    </a>so we may consider them into our massive
                    list of resource links.</li>
                  <li>If you have original works such as publications, cliparts,
                    or resources that are Scouting related, share them with us
                    so we can share them to everyone! Appropriate credits will
                    be accorded to you. Send them to <a href="mailto:publications@meritbadge.org.ph">publications@meritbadge.org.ph</a>.</li>
                  <li>Participate in the <a href="http://www.meritbadge.net.ph" target="_parent">Discussion
                  Network</a>. </li>
                </ul>
                <p class="maintext">The Merit Badge Center <strong>does not</strong> accept
                  monetary assistance. Please direct your monetary assistance
                to your local Scout council. </p>
                <p class="maintext"><span class="bluetext">May I link to a specific 
                  merit badge instead of the main page?</span><br />
                Yes. Please limit your links to one specific merit badge. If
                you plan to link to two or more merit badges, please use our
                <a href="/htm/mbquicklink.php">Merit Badge Quick Link</a> or link
                to our <a href="http://www.mbcenter.org/htm/meritbadgelist.php">main
                merit badge list page</a>. </p>
                <p class="maintext"><span class="bluetext"><strong>May I use or modify the Merit Badge
                    Worksheets?</strong></span><strong><br />
                </strong>Yes. I don't see why you will need to, but you can go
                ahead and modify it to fit your needs. You may also freely distribute
                these worksheets.</p>
                <p class="maintext"><span class="bluetext">Can the Merit Badge Worksheet be used in lieu of a Merit Badge Counselor?</span><br />
                  No. The Merit Badge worksheets were created to assist in the counseling process. The worksheets were not created to substitute or replace the Merit Badge Counselor. BSP advancement scheme requires a duly registered Merit Badge Counselor to certify the completion of the Merit Badge.</p>
                <p class="maintext"><span class="bluetext">May a Counselor simply require the worksheet to complete a Merit Badge?</span><br />
                  That is up to the counselor whether it meets his or her requirement as satisfactorily meeting the requirements of the Merit Badge as setforth by the BSP. </p>
                <p class="maintext"><span class="bluetext">May I use the merit 
                  badge and advancement rank graphics?</span><br />
                  The BSP allows the use of these graphics for the purpose of
                  the Scouting program. They should never be used for any other
                  purpose, especially if its use will blemish the good name of
                  the BSP, solicit donations for groups other than the BSP, or
                  promoting a product not endorsed by the BSP. </p>
                <p class="maintext"><strong class="bluetext">May I used the Merit Badge Center
                    Logo for our school publication?</strong><br />
                   You are granted limited use of <a href="/htm/pub/aboutlogo.php">the
                   logo</a> as provided by our
                   <a href="/htm/pub/mbcpterms.php">terms and conditions</a>.
                   The logo may not be altered in any way and may not be made
                   part of a bigger picture. It should be on solid background
                   (preferably white) with nothing covering any part of it. The
                   logo may not be used for any other purpose without the consent
                   of the Merit Badge Center. </p>
                <p class="maintext"><strong class="bluetext">May I print all the merit badge requirements
                    and distribute it to my unit?</strong><br />
                   Yes. But it will definitely be more economical to purchase
                   the <em>Merit
                   Badge and Advancement Handbook</em> from your local Scout
                   Shop. It will cost five to ten times as much to print all
                   these requirements out by yourself. The book includes all
                   rank requirements, merit badge requirements, steps in advancement,
                   steps in earning merit badges, list of specialist ratings,
                   and merit badge groups. </p>
                <p class="maintext"><span class="bluetext">May I distribute the 
                  Adobe Acrobat BSP forms?</span><br />
                Yes. You may post these forms on your website or include them
                into your CD distribution.</p>
                <p class="maintext"><span class="bluetext">Do you publish a list 
                  of merit badge counselors?</span><br />
                  No. We will not publish such a list for reasons of safety. Consult 
                  your unit leader for your own unit's list or your district leaders 
                for a copy of the district list of counselors.</p>
                <p class="maintext"><span class="bluetext">May I copy the contents 
                  of pages linked as resource links?</span><br />
                  You must direct your question to the owners or administrators 
                  of these resource links. Resources under &quot;<strong>Local 
                    Links</strong>&quot; are the property of the Merit Badge Center 
                  and may be freely copied and distributed.<strong> </strong></p>
              </blockquote>
              <p class="fineprint"><strong>ATTENTION SCOUTS AND SCOUTERS!</strong> 
                The Merit Badge Center is not a substitute for Merit Badge Counseling 
                with a Certified Merit Badge Counselor of the Boy Scouts of the 
                Philippines. The center is merely a tool to contribute to the 
                effectiveness of the Merit Badge Counseling process. Scouts should 
                consult with their unit leaders regarding to earning their merit 
                badges.</p>
              <blockquote> 
                <p class="maintext">&nbsp;</p>
              </blockquote>
              <!-- InstanceEndEditable --></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellpadding="3" cellspacing="1" class="tablebordertopbot">
          <tr>
            <td width="50%">Copyright &copy; 2020, Merit Badge Center, Philippines<br />
              Since August 4, 1999 - Fourth Edition September 30, 2003 </td>
            <td width="50%" align="right" background="/htm/pub/mbcpterms.php" class="fineprint"><a href="/htm/pub/mbcpterms.php" class="stealth">Terms, Conditions, and Information</a> </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellspacing="1" cellpadding="3">
          <tr>
            <td>
				
			</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
