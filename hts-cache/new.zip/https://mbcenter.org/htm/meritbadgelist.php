<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/mbcptemplate2007_2.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="fb:app_id" content="167734213309548"/>
<link rel="shortcut icon" href="/img/mbcp.ico" />
<script type="text/JavaScript" src="/script/genscripts2007.js"></script>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines</title>
<!-- InstanceEndEditable -->
<link href="/css/mainstyle2007.css" rel="stylesheet" type="text/css" />
<!-- InstanceBeginEditable name="head" --> 
<style type="text/css">
<!--
	a.red {
	color: #CC0000;
	text-decoration: none;
	border-bottom-width: 1pt;
	border-bottom-style: solid;
	border-bottom-color: #CC0000;
}
a.red:hover {

	color: #CC9900;
	text-decoration: none;
	border-bottom-width: 1px;
	border-bottom-style: dotted;
	border-bottom-color: #CC9900;
}
-->
</style>
<!-- InstanceEndEditable -->
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=204511906280785";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td bgcolor="#FFFFFF"><img src="/img/banner_main_2007.jpg" alt="Merit Badge Center, Philippines" width="768" height="86" /></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="25%" valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
              </tr>         
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/advancement.php" class="mainlink">Advancement Ranks</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/" class="mainlink" >Merit Badges (Alphabetical)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbcitizenrequired.php" class="mainlink" >Merit Badges (Citizen Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbeaglerequired.php" class="mainlink" >Merit Badges (Eagle Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbelectives.php" class="mainlink" >Merit Badges (Electives)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/ws.php" class="mainlink" >Advancement Worksheets</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/contactus/" class="mainlink" >Contact Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/aboutus.php" class="mainlink" >About Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/sitehelp.php" class="mainlink" >Help</a></td>
              </tr>
			  <tr>
			  	<td class="maintext">&nbsp;</td>
			  </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" --> 
              <br />
              <table width="100%" border="0" cellspacing="2" cellpadding="2">
              <tr>
                <td class="navbanner">Resources</td>
              </tr>
              <tr>
                <td><a href="/htm/pub/ws.php" class="mainlink">Worksheets </a></td>
              </tr>
            </table>
            <p>&nbsp;</p>
            <!-- InstanceEndEditable -->            
              </td>
              <td valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="5">
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><!-- InstanceBeginEditable name="MainBody" --> 
              <h1>Merit Badges</h1>
              <p class="maintext">Here are the merit badges in alphabetical order. Depending on your chosen vocational career path for Senior Scouts, some of the merit badges identified as required may not be required. For more information of what is and what is not required of you, check the <a href="advancement.php">advancement 
                  rank requirements</a>.              </p>
              <p class="maintext">First time earning a merit badge? <a href="pub/mblearnearn.php">Learn 
                how to earn your merit badge</a>. </p>
              <p class="maintext">Learn how to wear your <a href="/htm/pub/mbsash.php">Merit Badges</a>. </p>
              <table width="100%" border="0" cellspacing="1" cellpadding="1">
                <tr valign="top"> 
                  <td width="34%" class="maintext"><h2>A</h2>
                    <p class="sidelink"><a href="meritbadges.php?mb=agriculture&amp;req=n">Agriculture</a><br />
                          <a href="meritbadges.php?mb=animalstudy">Animal Study</a><br />
                          <a href="meritbadges.php?mb=archery">Archery</a><br />
                          <a href="meritbadges.php?mb=architecture">Architecture</a><br />
                          <a href="meritbadges.php?mb=art">Art</a><br />
                          <a href="meritbadges.php?mb=astronomy">Astronomy</a><br />
                          <a href="meritbadges.php?mb=athletics">Athletics</a><br />
                          <a href="meritbadges.php?mb=automobiling">Automobiling</a><br />
                          <a href="meritbadges.php?mb=aviation">Aviation</a></p>
                    <h2 class="sidelink">B</h2>
                    <p class="sidelink"><a href="meritbadges.php?mb=barbering">Barbering</a><br />
                          <a href="meritbadges.php?mb=basketry">Basketry</a><br />
                          <a href="meritbadges.php?mb=beekeeping">Beekeeping</a><br />
                          <a href="meritbadges.php?mb=birdstudy">Bird Study</a><br />
                          <a href="meritbadges.php?mb=blacksmithing">Blacksmithing</a><br />
                          <a href="meritbadges.php?mb=botany">Botany</a><br />
                          <a href="meritbadges.php?mb=bookbinding">Bookbinding</a><br />
                          <a href="meritbadges.php?mb=boating&amp;req=y">Boating</a><br />
                          <a href="meritbadges.php?mb=business">Business</a></p>
                    <h2 class="sidelink">C</h2>
                    <p class="sidelink"><a href="meritbadges.php?mb=camping&amp;req=y">Camping</a><br />
                        <a href="meritbadges.php?mb=carpentry">Carpentry</a><br />
                        <a href="meritbadges.php?mb=chemistry">Chemistry</a><br />
                        <a href="meritbadges.php?mb=citizenship&req=y">Citizenship</a><a href="meritbadges.php?mb=citizenshipinthecommunity&amp;req=y"><br />
                      Citizenship in the Community</a><br />
                      <a href="meritbadges.php?mb=citizenshipinthehome&amp;req=y">Citizenship 
                      in the Home</a><br />
                      <a href="meritbadges.php?mb=citizenshipinthenation&amp;req=y">Citizenship 
                      in the Nation</a><br />
                       <a href="meritbadges.php?mb=coconutgrowing">Coconut 
                      Growing</a><br />
                      <a href="meritbadges.php?mb=computers">Computers</a><br />
                      <a href="meritbadges.php?mb=cooking">Cooking</a><br />
                      <a href="meritbadges.php?mb=cropproduction">Crop Production</a><br />
                      <a href="meritbadges.php?mb=cycling">Cycling</a></p>
                    <h2 class="sidelink">D</h2>
                    <p class="sidelink"><a href="meritbadges.php?mb=dairying">Dairying</a><br />
                        <a href="meritbadges.php?mb=drafting">Drafting</a><br />
                        <a href="meritbadges.php?mb=dramatics">Dramatics</a><br />
                        <a href="meritbadges.php?mb=duckraising">Duck Raising</a></p>
                    <h2 class="sidelink">E</h2>
                    <p class="sidelink"><a href="meritbadges.php?mb=earngreen">Earn Green</a><a href="meritbadges.php?mb=ecology&amp;req=y"><br />
                      Ecology</a><br />
                      <a href="meritbadges.php?mb=electricity&amp;req=y">Electricity</a><br />
                      <a href="meritbadges.php?mb=electronics">Electronics</a><br />
                      <a href="meritbadges.php?mb=engineering">Engineering</a><br />
                      <a href="meritbadges.php?mb=environment">Environment</a><br />
                      <a href="meritbadges.php?mb=emergencypreparedness&amp;req=y">Emergency 
                      Preparedness</a> <br />
                    </p></td>
                  <td width="31%" class="maintext"><h2>F</h2>
                    <p><a href="meritbadges.php?mb=farmmanagement">Farm Management</a><a href="meritbadges.php?mb=filipinoheritage&amp;req=y"><br />
                          Filipino Heritage</a><br />
                          <a href="meritbadges.php?mb=firemanship">Firemanship</a><br />
                          <a href="meritbadges.php?mb=fishculture">Fish Culture</a><br />
                          <a href="meritbadges.php?mb=fishing">Fishing</a><br />
                          <a href="meritbadges.php?mb=firstaid&amp;req=y">First 
                      Aid</a><br />
                      <a href="meritbadges.php?mb=foodprocessing">Food Processing</a><br />
                      <a href="meritbadges.php?mb=forestry">Forestry</a><br />
                      <a href="meritbadges.php?mb=fruitcultivation">Fruit Cultivation</a></p>
                    <h2>G</h2>
                    <p><a href="meritbadges.php?mb=gardening">Gardening</a><br />
                        <a href="meritbadges.php?mb=globalcitizenship">Global Citizenship</a><br />
                        <a href="meritbadges.php?mb=gogreen">Go Green</a><br />
                        <a href="meritbadges.php?mb=growgreen">Grow Green</a> </p>
                    <h2>H</h2>
                    <p><a href="meritbadges.php?mb=handicraft">Handicraft</a><br />
                        <a href="meritbadges.php?mb=hiking">Hiking</a><a href="meritbadges.php?mb=hobbiesandcollection"><br />
                      Hobbies and Collection</a><br />
                      <a href="meritbadges.php?mb=hograising">Hog Raising</a><br />
                      <a href="meritbadges.php?mb=homerepairs">Home Repairs</a><br />
                      <a href="meritbadges.php?mb=horsemanship">Horsemanship</a></p>
                    <h2>I</h2>
                    <p><a href="meritbadges.php?mb=insectstudy">Insect Study</a><br />
                        <a href="meritbadges.php?mb=interpreting">Interpreting</a></p>
                    <h2>J</h2>
                    <p><a href="meritbadges.php?mb=journalism">Journalism</a></p>
                    <h2>L</h2>
                    <p><a href="meritbadges.php?mb=leathercraft">Leathercraft</a><br />
                        <a href="meritbadges.php?mb=lifesaving&amp;req=y">Lifesaving</a><a href="meritbadges.php?mb=livestockraising"><br />
                      Livestock 
                    Raising</a></p>
                    <h2>M</h2>
                    <p><a href="meritbadges.php?mb=machineshoppractice">Machine 
                      Shop Practice</a><br />
                      <a href="meritbadges.php?mb=marksmanship">Marksmanship</a><br />
                      <a href="meritbadges.php?mb=masonry">Masonry</a><br />
                      <a href="meritbadges.php?mb=metalwork">Metal Work</a><br />
                      <a href="meritbadges.php?mb=music">Music</a></p>
                    <h2>N</h2>
                    <p><a href="meritbadges.php?mb=naturelore">Nature Lore</a> <br />
                        <a href="meritbadges.php?mb=navigation">Navigation</a></p></td>
                  <td width="35%" class="maintext"><h2>P</h2>
                    <p><a href="meritbadges.php?mb=painting">Painting<br />
                    </a><a href="meritbadges.php?mb=pathfinding">Pathfinding</a><br />
                      <a href="meritbadges.php?mb=personalhealth">Personal Health</a><br />
                      <a href="meritbadges.php?mb=petcare">Pet Care</a><br />
                      <a href="meritbadges.php?mb=photography">Photography</a><br />
                      <a href="meritbadges.php?mb=physicalfitness&amp;req=y">Physical 
                        Fitness</a><br />
                        <a href="meritbadges.php?mb=pigeonraising&amp;req=y">Pigeon 
                        Raising</a><br />
                        <a href="meritbadges.php?mb=pioneering&amp;req=y">Pioneering</a><br />
                        <a href="meritbadges.php?mb=plumbing">Plumbing</a><br />
                        <a href="meritbadges.php?mb=pottery">Pottery</a><br />
                        <a href="meritbadges.php?mb=poultryraising">Poultry Raising</a><br />
                        <a href="meritbadges.php?mb=printing">Printing</a><br />
                        <a href="meritbadges.php?mb=publichealth">Public Health</a><br />
                        <a href="meritbadges.php?mb=publicspeaking">Public Speaking</a></p>
                    <h2>R</h2>
                    <p><a href="meritbadges.php?mb=rabbitraising">Rabbit Raising</a><br />
                        <a href="meritbadges.php?mb=radio">Radio</a><br />
                        <a href="meritbadges.php?mb=reading">Reading</a><br />
                        <a href="meritbadges.php?mb=reptileandamphibianstudy">Reptile 
                      and Amphibian Study</a><br />
                      <a href="meritbadges.php?mb=rizallore">Rizal Lore</a><br />
                      <a href="meritbadges.php?mb=ropework">Ropework</a></p>
                    <h2>S</h2>
                    <p><a href="meritbadges.php?mb=safety&amp;req=y">Safety</a><br />
                        <a href="meritbadges.php?mb=salesmanship">Salesmanship</a><br />
                        <a href="meritbadges.php?mb=scholarship">Scholarship</a><br />
                        <a href="meritbadges.php?mb=sculpture">Sculpture</a><br />
                        <a href="meritbadges.php?mb=seamanship">Seamanship</a><br />
                        <a href="meritbadges.php?mb=signaling">Signalling</a><br />
                        <a href="meritbadges.php?mb=snorkeling">Snorkeling</a><br />
                        <a href="meritbadges.php?mb=soilandwaterconservation&amp;req=y">Soil 
                      and Water Conservation</a><br />
                      <a href="meritbadges.php?mb=surveying">Surveying</a><br />
                      <a href="meritbadges.php?mb=swimming&amp;req=y">Swimming</a></p>
                    <h2>T</h2>
                    <p><a href="meritbadges.php?mb=tailoring">Tailoring</a><br />
                        <a href="meritbadges.php?mb=teamsports">Team Sports</a><br />
                        <a href="meritbadges.php?mb=treefarming&amp;req=y">Tree 
                    Farming</a></p>
                    <h2>W</h2>
                    <p><a href="meritbadges.php?mb=weather">Weather</a><br />
                        <a href="meritbadges.php?mb=wildlifeconservation">Wildlife 
                      Conservation</a><br />
                      <a href="meritbadges.php?mb=woodcarving">Wood Carving</a><br />
                      <a href="meritbadges.php?mb=woodwork">Wood Work</a></p></td>
                </tr>
              </table>
              <p class="maintext">&nbsp;</p>
              <!-- InstanceEndEditable --></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellpadding="3" cellspacing="1" class="tablebordertopbot">
          <tr>
            <td width="50%">Copyright &copy; 2020, Merit Badge Center, Philippines<br />
              Since August 4, 1999 - Fourth Edition September 30, 2003 </td>
            <td width="50%" align="right" background="/htm/pub/mbcpterms.php" class="fineprint"><a href="/htm/pub/mbcpterms.php" class="stealth">Terms, Conditions, and Information</a> </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellspacing="1" cellpadding="3">
          <tr>
            <td>
				
			</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
