<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/mbcptemplate2007_2.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="fb:app_id" content="167734213309548"/>
<link rel="shortcut icon" href="/img/mbcp.ico" />
<script type="text/JavaScript" src="/script/genscripts2007.js"></script>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines</title>
<!-- InstanceEndEditable -->
<link href="/css/mainstyle2007.css" rel="stylesheet" type="text/css" />
<!-- InstanceBeginEditable name="head" --> 
<style type="text/css">
<!--
.redtext {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #FF0000;
}
.bluetext {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #000066;
}
-->
</style><!-- InstanceEndEditable -->
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=204511906280785";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td bgcolor="#FFFFFF"><img src="/img/banner_main_2007.jpg" alt="Merit Badge Center, Philippines" width="768" height="86" /></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="25%" valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
              </tr>         
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/advancement.php" class="mainlink">Advancement Ranks</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/" class="mainlink" >Merit Badges (Alphabetical)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbcitizenrequired.php" class="mainlink" >Merit Badges (Citizen Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbeaglerequired.php" class="mainlink" >Merit Badges (Eagle Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbelectives.php" class="mainlink" >Merit Badges (Electives)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/ws.php" class="mainlink" >Advancement Worksheets</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/contactus/" class="mainlink" >Contact Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/aboutus.php" class="mainlink" >About Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/sitehelp.php" class="mainlink" >Help</a></td>
              </tr>
			  <tr>
			  	<td class="maintext">&nbsp;</td>
			  </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" --> <br />
				<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="navbanner">MBCP Information</td>
  </tr>
  <tr>
    <td><a href="/htm/pub/mbcpaccolades.php" class="mainlink">Accolades</a></td>
  </tr>
  <tr>
    <td ><a href="/htm/pub/aboutauthor.php" class="mainlink">About
        the Author</a></td>
  </tr>
  <tr>
    <td ><a href="/htm/pub/credits.php" class="mainlink">Credits
        Due</a></td>
  </tr>
  <tr>
    <td ><a href="/htm/pub/ip.php" class="mainlink">Intellectual
        Property Policy</a></td>
  </tr>
  <tr>
    <td ><a href="/htm/sitemap.php" class="mainlink">Site Map</a></td>
  </tr>
  <tr>
    <td ><a href="/htm/pub/mbcphistory.php" class="mainlink">Site
        History</a></td>
  </tr>
  <tr>
    <td ><a href="/htm/pub/aboutlogo.php" class="mainlink">Site
        Logo</a></td>
  </tr>
</table>
              <!-- InstanceEndEditable -->            
              </td>
              <td valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="5">
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><!-- InstanceBeginEditable name="MainBody" --> 
              <h1>About the Author</h1>
              <p class="maintext">I was introduced to Scouting in 1992 when I joined Senior Outfit 1 of Quezon City Council. Served in multiple position-of-office throughout the years in two National Scout Associations: Patrol Quartermaster, Senior Crew Leader, Assistant Outfit Advisor, Troop Leader, Institutional Advancement Chair, District Executive, Assistant Scoutmaster, Scoutmaster, District Committee Member, Troop Committee Member, and  Crew Committee Chairman.</p>
              <p class="h2">Citations</p>
              <ul class="maintext">
                <li><strong>International Service Team</strong>, 12th National Jamboree, General Association Scouts of China (2024)</li>
                <li><strong>USA International Service Team</strong>, 24th World Scout Jamboree (2019)</li>
                <li><strong>Assistant Course Director</strong>, GLAAC National Youth Leadership Training (2017-2018)</li>
                <li><strong>Bronze Service Award</strong>, Brighton Venturers, Manila Council, Boy Scouts of the Philippines (2016)</li>
                <li><strong>NESA Legacy Fellow</strong>, Boy Scouts of America (2015)</li>
                <li><strong>Order of the Condor</strong>, Interamerican Scout Foundation (2014)</li>
                <li><strong>Certificate of Commendation</strong>, Quezon City Council, Boy Scouts of the Philippines (2013)</li>
                <li><strong>Founding Fellow</strong>, Order of the Arrow Legacy Fellowship (2013)</li>
                <li><strong>Associate Member</strong>, Asia-Pacific Regional Scout Foundation (2012)</li>
                <li><strong>Order of the Arrow</strong>, Boy Scouts of America (2012)</li>
                <li><strong>District Award of Merit</strong>, Boy Scouts of America (2012)</li>
                <li><strong>Platinum Star Award</strong>, Los Angeles Chapter, California Credit Union League (2012)</li>
                <li><strong>Charles M. Clark Memorial Award</strong>, Western CUNA Management School (2011)</li>
                <li><strong>Young Credit Union People Nominee</strong>, World Council of Credit Unions (2011)</li>
                <li><strong>James E. West Fellow</strong>, Boy Scouts of America (2011)</li>
                <li><strong>District Committee Key Award</strong>, Boy Scouts of America (2010)</li>
                <li><strong>Venturing Leader Training Award</strong>, Boy Scouts of America (2010)</li>
                <li><strong>Tomorrow's Star Award</strong>, California Credit Union League (2010)</li>
                <li><strong>Member (#428)</strong>, Association of Top/Achiever Scouts (2009)</li>
                <li><strong>Silver W3 Award</strong> (for Eliseo Art Silva), International Academy of the Visual Arts (2009)</li>
                <li><strong>Certificate of Recognition</strong> (Outstanding Service to the Community), City of Carson, CA (2009)</li>
                <li><strong>Order of Knots</strong> (Gold Level), Grace Christian College Scouts (2008) </li>
                <li><strong class="maintext">Certificate of Commendation</strong>, Governance Camp, TOBSPA (2007)</li>
                <li><strong class="maintext">Silver W3 Award</strong> (for Merit Badge Center), International Academy of the Visual Arts (2006)</li>
                <li><strong class="maintext">Finalist </strong>(for Merit Badge Center), 9th Philippine Web Awards (2006)</li>
                <li><strong class="maintext">Semi-Finalist</strong> (for Merit Badge Center), 8th Philippine Web Awards (2005)</li>
                <li><strong>St. Miguel FSC Fellow</strong>, Lasallian Legacy Fund (2004)</li>
                <li><strong class="maintext">Weekly Pick</strong>, Yahoo! Asia (2003)</li>
                <li><strong class="maintext">Semi-Finalist</strong> (for Merit Badge Center), 4th Philippine Web Awards (2001)</li>
                <li><strong>Bronze Service Award Nominee</strong>, Boy Scouts of the Philippines (2000)</li>
                <li><strong class="maintext">Scout Wood Badge</strong>, Boy Scouts of the Philippines (2000)</li>
                <li><strong>Grace of God Award</strong>, Grace Christian Service Scouts (1999)</li>
                <li><strong>Certificate of Commendation</strong>, Boy Scouts of the Philippines (1998)  </li>
                <li><strong>Program Staff</strong>, Philippine Centennial Jamboree, Boy Scouts of the Philippines (1998)</li>
                <li><strong class="maintext">Eagle Scout Award</strong>, Boy Scouts of the Philippines (1997)</li>
                <li><strong>Philippine Contingent Member</strong>, 11th Nippon Scout Jamboree (1994)</li>
                </ul>
              <p class="h2">Education and Certification</p>
              <ul class="maintext">
                <li><strong>Graduate with Honors</strong>, Western CUNA Management School (2011)</li>
                <li><strong>B.S. Computer Science</strong>, De La Salle University-Manila (2000)</li>
                <li><strong>High School Diploma</strong>, Grace Christian High School (1996) </li>
              </ul>
              <p class="h2">Certification</p>
              <ul class="maintext">
                <li><strong>Credit Union Compliance Officer</strong>, America's Credit Union (2025)</li>
                <li><strong>Certified Credit Union Investment Professional</strong>, Credit Union National Association (2023)</li>
                <li><strong>Credit Union Compliance Expert</strong>, Credit Union National Association (2013)</li>
                <li><strong>Range Safety Officer</strong>, National Rifle Association (2013)</li>
                <li><strong>Certified Credit Unoin Executive</strong>, Western CUNA Management School (2011)</li>
                <li><strong>Certified First Aid/CPR/AED</strong>, American Red Cross (2011)</li>
                <li><strong>Certified Compliance Officer</strong>, National Association of Federal Credit Unions (2007)</li>
                <li><strong>Certified Food Safety Manager</strong>, National Restaurant Association (2003)</li>
              </ul>
              <p>&nbsp;</p>
          <!-- InstanceEndEditable --></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellpadding="3" cellspacing="1" class="tablebordertopbot">
          <tr>
            <td width="50%">Copyright &copy; 2020, Merit Badge Center, Philippines<br />
              Since August 4, 1999 - Fourth Edition September 30, 2003 </td>
            <td width="50%" align="right" background="/htm/pub/mbcpterms.php" class="fineprint"><a href="/htm/pub/mbcpterms.php" class="stealth">Terms, Conditions, and Information</a> </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellspacing="1" cellpadding="3">
          <tr>
            <td>
				
			</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
