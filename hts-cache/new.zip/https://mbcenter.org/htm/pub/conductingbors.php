<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/mbcptemplate2007_2.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="fb:app_id" content="167734213309548"/>
<link rel="shortcut icon" href="/img/mbcp.ico" />
<script type="text/JavaScript" src="/script/genscripts2007.js"></script>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines</title>
<!-- InstanceEndEditable -->
<link href="/css/mainstyle2007.css" rel="stylesheet" type="text/css" />
<!-- InstanceBeginEditable name="head" --><!-- InstanceEndEditable -->
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=204511906280785";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td bgcolor="#FFFFFF"><img src="/img/banner_main_2007.jpg" alt="Merit Badge Center, Philippines" width="768" height="86" /></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="25%" valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
              </tr>         
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/advancement.php" class="mainlink">Advancement Ranks</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/" class="mainlink" >Merit Badges (Alphabetical)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbcitizenrequired.php" class="mainlink" >Merit Badges (Citizen Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbeaglerequired.php" class="mainlink" >Merit Badges (Eagle Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbelectives.php" class="mainlink" >Merit Badges (Electives)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/ws.php" class="mainlink" >Advancement Worksheets</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/contactus/" class="mainlink" >Contact Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/aboutus.php" class="mainlink" >About Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/sitehelp.php" class="mainlink" >Help</a></td>
              </tr>
			  <tr>
			  	<td class="maintext">&nbsp;</td>
			  </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" --> <br />
            <table width="100%" border="0" cellspacing="2" cellpadding="2">
              <tr> 
                <td class="navbanner">Additional Links</td>
              </tr>
              <tr> 
                <td class="navborder"><a href="/pub/pdf/les_conductingbors.pdf" class="mainlink">This 
                  Page in PDF (110KB)</a></td>
              </tr>
            </table>
            <p>&nbsp;</p>
            <!-- InstanceEndEditable -->            
              </td>
              <td valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="5">
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><!-- InstanceBeginEditable name="MainBody" --> 
                  <h1>Conducting Boards of Review</h1>
                  <p class="maintext"><strong><img src="/img/images/pic_bor01.jpg" width="175" height="143" align="right" /></strong>A 
                    Troop or an Outfit should conduct Boards of Review at least 
                    <strong>once a month</strong>. Mostly, those who are advancing 
                    in rank or have earned a merit badge are those who are subject 
                    to the review. I however (meaning it is my opinion) would 
                    recommend that even Scouts who are not earning a merit badge 
                    and not advancing in rank should also be reviewed. The purpose 
                    being is to review why the Scout didn't earn anything this 
                    month, which should be a concern.</p>
                  <p class="maintext">The practice of some councils and districts 
                    of <strong>conducting one Board of Review a year (mass Board 
                    of Review) should be discouraged</strong>! Boards of Review 
                    should be conducted whenever at least one Scout is ready for 
                    review. I have at least six of my friends who never got their 
                    Eagle Scout because of this slight technicality that they 
                    turned 17 years of age before the next scheduled Board of 
                    Review. So as you can see, mass Boards of Review only causes 
                    delay on the Scout's advancement. </p>
                  <p class="maintext">I discourage the one-on-one session where 
                    one adult reviews one Scout. Moreso, the one-to-many where 
                    one adult reviews two or more Scouts. This totally defeated 
                    the purpose of the Board of Review of being a panel of adults. 
                    It also gives room for the lack of objectivity of one adult 
                    towards a Scout or two. It is recommended that the Board of 
                    Review, as a panel, reviews one Scout at a time, so that the 
                    questions can be more specific to the Scout and the board 
                    can go into a little bit of detail.</p>
                  <h2>Who is the Board of Review?</h2>
                  <p class="maintext"> With the exception of the Eagle, Venturer, 
                    and sometimes the Outdoorsman Scout ranks, the Board of Review 
                    is composed of three or more members. It is recommended that 
                    the unit committee be used for this purpose. However you can 
                    also invite some friends of Scouting like the parish priest 
                    of the Scout's church or even active parents.</p>
                  <p class="maintext">The Scout's parent, relatives, and unit 
                    leaders are disqualified to become members of his Board of 
                    Review for obvious reasons. </p>
                  <p class="maintext">For Eagle, Venturer, and Outdoorsman Scout 
                    ranks, the Board of Review is composed of people from the 
                    Scouting community in general. These reviews are conducted 
                    by the local councils and districts.</p>
                  <h2>What Does the Board of Review Achieve?</h2>
                  
              <p class="maintext">It is to ensure that the Scout has met the requirements 
                for the rank. But remember that <strong>this is not a re-test 
                of his skill</strong>. The most common mis-conception about the 
                Board of Review is that people think they are there to re-test 
                the Scout on skills like knot tying and first aid. Well, if this 
                was the case it should've been called the <strong>Board of Examination</strong> 
                and not the <strong>Board of Review</strong>.</p>
                  <p class="maintext">It is a common practice in some regions 
                    to re-test candidates for Eagle Scouts in swimming skills. 
                    This is strongly discouraged! It is not the place of the Board 
                    of Review to perform such a test. Such a test underminds the 
                    ability of Swimming Merit Badge Counselor and the entire Merit 
                    Badge counseling process.</p>
                  <p class="maintext">The Board of Review is like a job interview 
                    -- we just talk. It is also the goal of the review to check 
                    what kind of experience the Scout is having in the unit (is 
                    he enjoying himself). Through these reviews, we can also determine 
                    if the unit leader is meeting the goals of Scouting through 
                    varied activities.</p>
                  <p class="maintext">This will also be a venue to encourage (or 
                    even pressure) the Scout to achieve the next rank. If he is 
                    turning 17 years of age and is only being reviewed for the 
                    Venturer Rank, the Board of Review must make him realize that 
                    he is running out of time. Sometimes a little push is in order.</p>
                  <h2>When Do I Conduct a Board of Review?</h2>
                  <p class="maintext">Boards of Review should be conducted at 
                    least <strong>once a month</strong>. It is recommended that 
                    you make it as part of your regular schedule for Scouting, 
                    like the first Saturday of each month. There are no set time-frame 
                    of when a Board of Review can be conducted. It is totally 
                    up to the unit when they want to schedule it, it is prudent 
                    however that the Board of Review does not conflict with district 
                    or council Boards of Review and activities.</p>
                  
              <p class="maintext">For Eagle, Venturer, and Outdoorsman Scout ranks, 
                turn in the paper works to the district or local council as soon 
                as he is qualified. This preserves the boys right to be reviewed 
                for the rank.</p>
                  <h2>How Do I Condcut a Board of Review? -- Good Question.</h2>
                  <p class="maintext">Get a list of people willing to help out 
                    in the Board of Review. This list will help you out tremendously 
                    when the time comes and you need to call for volunteers.</p>
                  <p class="maintext">As i mentioned earlier, have a regular schedule 
                    for your Boards of Review. This will become a habit that everyone 
                    will know that a Board of Review is coming because it is almost 
                    the first Saturday of the month for example. Call for volunteers 
                    at least a month or so ahead. This gives you and your volunteers 
                    enough time to place it on their schedules.</p>
                  <p class="maintext">At least two weeks before the Board of Review, 
                    check to see how many Scouts you need to review. You may need 
                    to have two or even more panels to handle the volume, this 
                    gives you enough time to call for more volunteers. </p>
                  <p class="maintext">Convene with your volunteers at least a 
                    week before with the list of Scouts undergoing the Board of 
                    Review. Have generic questions that will be based on the the 
                    rank requirements or merit badge requirements (but remember 
                    this is not a re-test, it is only an interview). Also, develop 
                    questions specific to some Scouts. You might want to tackle 
                    Joey's weakness, or might want to avoid questions about family 
                    for Henry, who just went through a family-related problem. 
                    Aside from these scripted questions, give your Board of Review 
                    a free-hand on questions as well, but inform them of questions 
                    that are hands-off (like Henry's family problem).</p>
                  <p class="maintext">Questions should be open-ended to give the 
                    Scout the opportunity to practice his interview skills. Simple 
                    questions should be avoided as much as possible. Follow-up 
                    some answers with additional questions of why and how.</p>
                  <p class="maintext">On the day of the Board of Review, conduct 
                    it normally. One Scout per panel at a time. I encourage the 
                    habit of having the unit leader be there and present the Scout 
                    to the Board of Review. <em>May I present to the Board of 
                    Review Pathfinder Scout Henry Dela Cruz who is here to be 
                    reviewed on his First Aid and Ecology Merit Badges</em>. In 
                    some cases, the Scout may even present himself to the Board 
                    of Review.</p>
                  <p class="maintext">The Board of Review should last no longer 
                    than 15 to 20 minutes for an advancement rank and no longer 
                    than 10 minutes for one merit badge. The Board of Review then 
                    makes a decision of whether to award the Scout with the advancement 
                    rank or the merit badge. </p>
                  <p class="maintext">The Board of Review must not be afraid to 
                    disqualify a Scout should they find out through the course 
                    of the interview that he did not meet the requirement. Example, 
                    when a candidate for Pathfinder Scout was asked where he went 
                    swimming and replied that they never went swimming at all. 
                    The Scout is disqualified because he did not obviously meet 
                    the requirement 9 of the Pathfinder Scout Rank:</p>
                  <ol>
                    <li value="9" class="maintext"><em>Demonstrate your ability 
                      to swim at least fifty (50) meters using any stroke. Float 
                      as motionless as possible in deep water for at least one 
                      minute. Explain the eight (8) point safe swim defense plan. 
                      Demonstrate three (3) non-swimming methods of rescuing the 
                      drowning person. </em></li>
                  </ol>
                  <p class="maintext">Also, the Board of Review must be keen on 
                    particular items such as how long it took the Scout to earn 
                    a particular merit badge. For instance, a Scout who claims 
                    that it only took him one month to earn the <a href="/htm/meritbadges.php?mb=citizenshipinthehome">Citizenship 
                    in the Home</a> merit badge did not earn the merit badge at 
                    all because of requirement 7 of the merit badge:</p>
                  <ol start="7">
                    <li class="maintext"><em>Make a budget and keep a record of 
                      your own income and/or allowances and expenses for <strong>two 
                      months</strong>. Explain why it is wise to live within one's 
                      means.</em> </li>
                  </ol>
                  <p class="maintext">Then again, it is only fitting that I remind 
                    you that the objective of the Board of Review is not to be 
                    a huge hurdle that a Scout must leap over of. The objective 
                    of the Board of Review is to ensure that each Scout is getting 
                    what he is expected to receive from the Scouting program.</p>
                  <p class="maintext">After all has been said and done, don't 
                    forget to complete the <a href="/downloads/REP_BOR.pdf">Report 
                    of the Board of Review</a> form in triplicate and to be submitted 
                    to the local district or council office.</p>
                  <ol start="7">
                    <ol>
                      <span class="maintext"> </span> 
                    </ol>
                  </ol>
                  <!-- InstanceEndEditable --></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellpadding="3" cellspacing="1" class="tablebordertopbot">
          <tr>
            <td width="50%">Copyright &copy; 2020, Merit Badge Center, Philippines<br />
              Since August 4, 1999 - Fourth Edition September 30, 2003 </td>
            <td width="50%" align="right" background="/htm/pub/mbcpterms.php" class="fineprint"><a href="/htm/pub/mbcpterms.php" class="stealth">Terms, Conditions, and Information</a> </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellspacing="1" cellpadding="3">
          <tr>
            <td>
				
			</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
