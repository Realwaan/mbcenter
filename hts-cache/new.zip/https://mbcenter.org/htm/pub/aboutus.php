<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/mbcptemplate2007_2.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="fb:app_id" content="167734213309548"/>
<link rel="shortcut icon" href="/img/mbcp.ico" />
<script type="text/JavaScript" src="/script/genscripts2007.js"></script>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines</title>
<!-- InstanceEndEditable -->
<link href="/css/mainstyle2007.css" rel="stylesheet" type="text/css" />
<!-- InstanceBeginEditable name="head" --><!-- InstanceEndEditable -->
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=204511906280785";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td bgcolor="#FFFFFF"><img src="/img/banner_main_2007.jpg" alt="Merit Badge Center, Philippines" width="768" height="86" /></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="25%" valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
              </tr>         
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/advancement.php" class="mainlink">Advancement Ranks</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/" class="mainlink" >Merit Badges (Alphabetical)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbcitizenrequired.php" class="mainlink" >Merit Badges (Citizen Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbeaglerequired.php" class="mainlink" >Merit Badges (Eagle Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbelectives.php" class="mainlink" >Merit Badges (Electives)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/ws.php" class="mainlink" >Advancement Worksheets</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/contactus/" class="mainlink" >Contact Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/aboutus.php" class="mainlink" >About Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/sitehelp.php" class="mainlink" >Help</a></td>
              </tr>
			  <tr>
			  	<td class="maintext">&nbsp;</td>
			  </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" --> <br />
              <p>&nbsp;</p>
            <p>&nbsp;</p>
            <!-- InstanceEndEditable -->            
              </td>
              <td valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="5">
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><!-- InstanceBeginEditable name="MainBody" --> 
                <h1><a href="http://www.proudlypinoy.org/" target="_blank"><img src="/img/buttons/proudlypinoyontrans.png" alt="Proudly Pinoy" width="150" height="151" hspace="5" vspace="5" border="0" align="right" /></a>About Us </h1>
                <p><span class="maintext"><strong>                The Merit Badge Center</strong> is
                the online resource center for the members of the <a href="http://www.scouts.org.ph/" target="_blank">Boy
                  Scouts of the Philippines</a>. It is our purpose to assist
                the leaders and youth members of this organization in
                their effort to deliver the Scouting program. We have a compendium
                of resources coming from various sources with some original
                works of our own. Included in this collection are links to
                useful websites that provides information related to rank and
                merit badge requirements.</span></p>
                <ul class="maintext">
                  <li><a href="/htm/pub/mbcpaccolades.php">Accolades</a></li>
                  <li><a href="/htm/pub/aboutauthor.php">About the Author</a></li>
                  <li><a href="/htm/pub/credits.php">Credits Due</a></li>
                  <li><a href="/htm/pub/ip.php">Intellectual Property Policy</a></li>
                  <li><a href="/htm/sitemap.php">Site Map</a></li>
                  <li><a href="/htm/pub/mbcphistory.php">Site History</a></li>
                  <li><a href="/htm/pub/aboutlogo.php">Site Logo</a></li>
                </ul>
                <p>&nbsp;</p>
              <!-- InstanceEndEditable --></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellpadding="3" cellspacing="1" class="tablebordertopbot">
          <tr>
            <td width="50%">Copyright &copy; 2020, Merit Badge Center, Philippines<br />
              Since August 4, 1999 - Fourth Edition September 30, 2003 </td>
            <td width="50%" align="right" background="/htm/pub/mbcpterms.php" class="fineprint"><a href="/htm/pub/mbcpterms.php" class="stealth">Terms, Conditions, and Information</a> </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellspacing="1" cellpadding="3">
          <tr>
            <td>
				
			</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
