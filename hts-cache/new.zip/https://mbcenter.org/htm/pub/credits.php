<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/mbcptemplate2007_2.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="fb:app_id" content="167734213309548"/>
<link rel="shortcut icon" href="/img/mbcp.ico" />
<script type="text/JavaScript" src="/script/genscripts2007.js"></script>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines</title>
<!-- InstanceEndEditable -->
<link href="/css/mainstyle2007.css" rel="stylesheet" type="text/css" />
<!-- InstanceBeginEditable name="head" --> 
<style type="text/css">
<!--
.redtext {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #FF0000;
}
.bluetext {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #000066;
}
-->
</style><!-- InstanceEndEditable -->
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=204511906280785";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td bgcolor="#FFFFFF"><img src="/img/banner_main_2007.jpg" alt="Merit Badge Center, Philippines" width="768" height="86" /></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="25%" valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
              </tr>         
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/advancement.php" class="mainlink">Advancement Ranks</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/" class="mainlink" >Merit Badges (Alphabetical)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbcitizenrequired.php" class="mainlink" >Merit Badges (Citizen Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbeaglerequired.php" class="mainlink" >Merit Badges (Eagle Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbelectives.php" class="mainlink" >Merit Badges (Electives)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/ws.php" class="mainlink" >Advancement Worksheets</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/contactus/" class="mainlink" >Contact Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/aboutus.php" class="mainlink" >About Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/sitehelp.php" class="mainlink" >Help</a></td>
              </tr>
			  <tr>
			  	<td class="maintext">&nbsp;</td>
			  </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" --><br />
				<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="navbanner">MBCP Information</td>
  </tr>
  <tr>
    <td><a href="/htm/pub/mbcpaccolades.php" class="mainlink">Accolades</a></td>
  </tr>
  <tr>
    <td ><a href="/htm/pub/aboutauthor.php" class="mainlink">About
        the Author</a></td>
  </tr>
  <tr>
    <td ><a href="/htm/pub/credits.php" class="mainlink">Credits
        Due</a></td>
  </tr>
  <tr>
    <td ><a href="/htm/pub/ip.php" class="mainlink">Intellectual
        Property Policy</a></td>
  </tr>
  <tr>
    <td ><a href="/htm/sitemap.php" class="mainlink">Site Map</a></td>
  </tr>
  <tr>
    <td ><a href="/htm/pub/mbcphistory.php" class="mainlink">Site
        History</a></td>
  </tr>
  <tr>
    <td ><a href="/htm/pub/aboutlogo.php" class="mainlink">Site
        Logo</a></td>
  </tr>
</table>
	
            <!-- InstanceEndEditable -->            
              </td>
              <td valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="5">
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><!-- InstanceBeginEditable name="MainBody" --> 
              <h1>Website Credits</h1>
              <p align="center" class="maintext"><em>&quot;To Help Other People 
                at All Times&quot;</em></p>
              <p align="left" class="maintext">The Merit Badge Center was founded 
                to contribute to the education of our youth through Scouting. 
                Our purpose is to help Scouts and Scouters achieve their Scouting 
                goals. Often, we find ourselves on the receiving end and without 
                the help of other people, creating and maintaining this website 
                would have been impossible. We dedicate an extremely small portion 
                of our web space and bandwidth to the people who have lived to 
                symbolize the point of the Scout Law of being <em>&quot;A Scout 
                is Helpful&quot;</em>.</p>
              <blockquote> 
                <p class="maintext"><strong>The Boy Scouts of the Philippines</strong><br />
                  <span class="fineprint">For allowing us to publish and use
                   the Merit Badge requirements, logos, graphics, and other Boy
                Scout propriety materials on this website.</span></p>
                <p class="maintext"><strong>Christina Pavilion-Fajardo<br />
                  </strong><span class="fineprint">A great friend from the Campus
                  Crusade for Christ in De La Salle University-Manila. She was
                  gracious enough to let me borrow her HTML book for the entire
                  summer of 1999 when I was starting to learn web developing
                  by myself. Currently she is actively involved with the ministry
                  of Campus Crusade for Christ within Metro Manila, particularly
                  with De La Salle University-Manila.</span> </p>
                <p><strong class="maintext">Christopher Ragudo</strong><br />
                  <span class="fineprint">A dedicated Scouter who once served as a professional with the
                  Public Relations Division of the Boy Scouts of the Philippines.
                  Currently he is the Outfit Advisor of Ramon Magsaysay (Cubao)
                  High School Scouting Unit. Even before his involvement as a
                  professional in the BSP he has been an ardent supporter of
                  the use of the World-Wide-Web to benefit Scouting in the Philippines.
                  He was the driving force in reviving the Internet presence
                  of the BSP through an official website, which the BSP leadership
                  did not support, and in giving Filipino boys the opportunity
                  to join the Jamboree On The Internet. He continues on today
                  as a defacto ambassador of the Merit Badge Center, promoting
                  the website to whoever he meets. </span></p>
                <p><span class="maintext"><strong>Dr. Jacobb-Josephson Caones<br />
                  </strong></span><span class="fineprint">He is a Doctor of Veterinary
                   Medicine from the University of the Philippines-Los Ba&ntilde;os.
                    He is a fellow Scouter. A fellow Wood Badge, an Eagle Scout from the Boy Scouts
                   of  America, Arrowman with the honor of Brotherhood, and has
                   the  Fourth Degree exemplification from the Knights of Columbus.
                    He served as the charter Public Relations officer for the
                   Eagle  Scout Association of the Philippines (ESAP) in Luzon,
                   then president  of the ESAP Luzon 2 chapter. He also served
                   as an executive  board member of the Quezon City Council of
                   the Boy Scouts of  the Philippines. He
                   diligently  typed all the Merit Badge Requirements from the
                   Advancement  and Merit Badge Handbook into HTML encoded files
                   and graciously  housed the Merit Badge Center into his own
                   web space until we  found our permanent home. Currently, he
                   is the Institutional  Scouting Committee Chairman for Grace
                   Christian High School  in Quezon City, a captain of industry
                   managing his own business,  and completing his Certificate
                   of Teaching Program at the Philippine  Normal University.
                   He is a very loyal Scouter, so loyal that he endured six years
                   of cruel and unusal discrimination of the Boy Scouts of the
                   Philippines who blatantly refused to award him his wood badge
                   beads despite completely all the requirements. </span></p>
                <p class="maintext"><strong>Pastor Leonides T. Son</strong><br />
                  <span class="fineprint">He is currently the National Training Commissioner of the Boy Scouts of the Philippines. He is a minister who has never
                  ceased to show his faith in God. He has been instrumental in
                  spreading the website to Scouters in training and have shared
                  many of his resources to others through this website and other
                  means. He is responsible in computerizing much of the handouts
                  for the Basic Training Course for Troop Leader (available on
                  this site) and other training materials within his council.</span></p>
                <p class="maintext"><strong>Michael Kauffmann<br />
                  </strong><span class="fineprint">The optimist. The brains behind 
                    the <a href="http://www.meritbadge.com" target="_blank">Merit 
                      Badge Research Center</a> that serves the members of the Boy 
                    Scouts of America. I hold this guy responsible for starting 
                    this idea.</span></p>
                <p class="maintext"><strong>Sir Peter Yu</strong><br />
                  <span class="fineprint">He was the Founder and Scoutmaster Emeritus of Grace Christian High School in Quezon City. He was a mentoring figure to me during my years as an adult leader in Scouting. He never fails to provide timely advice even on matters beyond Scouting. His guidance made me a more effective Scout leader. He is now with our Great Scoutmaster. May you rest in peace sir.</span></p>
                <p class="maintext"><strong>Ralphie Ng</strong><br />
                  <span class="fineprint">I have never met this guy and have never corresponded with him
                    at all. But he is responsible for the fabulous graphic arts
                    of advancement and position badges available for download on
                    this website. His works which he shared to Leonides T. Son
                    found its way to this website and shared to thousands of Scouts
                    on the Internet. He is from Manila Council.</span> </p>
                <p class="maintext"><strong>Sir Roman Sirilan III</strong><br />
                  <span class="fineprint">The only person that I have referred 
                    to as My Scoutmaster. He is responsible for making me decide 
                    to join Scouting when I was in high school. Since then, he was 
                    the driving force behind my career in Scouting. I am an Eagle 
                  Scout and a Wood Badge because of his guidance.</span></p>
                <p class="maintext"><strong>Prof. Sonny Medina</strong><br />
                  <span class="fineprint">An energetic Scouter who once served as the defacto Public Relations
                  person of the Merit Badge Center by kick-starting the word
                  about the existence of the website. This guy was more excited
                  about the website than I was. He was a university professor
                  in Manila and often rub shoulders with the Boy Scouts of the
                  Philippines leadership. He was the adviser to the Ten Outstanding
                  Boy Scouts of the Philippines Association (TOBSPA). He is now with our Great Scoutmaster. May you rest in peace prof.</span></p>
                <p class="maintext"><strong>The Scouts and Scouters of the Philippines</strong><br />
                  <span class="fineprint">For your continued support, words 
                  of encouragements, and must appreciated recognition.</span></p>
                <p>&nbsp;</p></blockquote>
              <!-- InstanceEndEditable --></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellpadding="3" cellspacing="1" class="tablebordertopbot">
          <tr>
            <td width="50%">Copyright &copy; 2020, Merit Badge Center, Philippines<br />
              Since August 4, 1999 - Fourth Edition September 30, 2003 </td>
            <td width="50%" align="right" background="/htm/pub/mbcpterms.php" class="fineprint"><a href="/htm/pub/mbcpterms.php" class="stealth">Terms, Conditions, and Information</a> </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellspacing="1" cellpadding="3">
          <tr>
            <td>
				
			</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
