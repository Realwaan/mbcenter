<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/mbcptemplate2007_2.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="fb:app_id" content="167734213309548"/>
<link rel="shortcut icon" href="/img/mbcp.ico" />
<script type="text/JavaScript" src="/script/genscripts2007.js"></script>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines</title>
<!-- InstanceEndEditable -->
<link href="/css/mainstyle2007.css" rel="stylesheet" type="text/css" />
<!-- InstanceBeginEditable name="head" --> 
<style type="text/css">
<!--
.bluetext {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #000066;
}
-->
</style>
<!-- InstanceEndEditable -->
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=204511906280785";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td bgcolor="#FFFFFF"><img src="/img/banner_main_2007.jpg" alt="Merit Badge Center, Philippines" width="768" height="86" /></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="25%" valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
              </tr>         
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/advancement.php" class="mainlink">Advancement Ranks</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/" class="mainlink" >Merit Badges (Alphabetical)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbcitizenrequired.php" class="mainlink" >Merit Badges (Citizen Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbeaglerequired.php" class="mainlink" >Merit Badges (Eagle Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbelectives.php" class="mainlink" >Merit Badges (Electives)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/ws.php" class="mainlink" >Advancement Worksheets</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/contactus/" class="mainlink" >Contact Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/aboutus.php" class="mainlink" >About Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/sitehelp.php" class="mainlink" >Help</a></td>
              </tr>
			  <tr>
			  	<td class="maintext">&nbsp;</td>
			  </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" -->
                        <p>&nbsp;</p>
            <!-- InstanceEndEditable -->            
              </td>
              <td valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="5">
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><!-- InstanceBeginEditable name="MainBody" --> 
                  <h1>Problems with the Requirements</h1>
                  <p class="maintext">I suppose it is similar to every National 
                    Scout Association. The national level creates the program 
                    and makes huge changes, and they let us deal with the problems 
                    that spurs out of it. If you have given close attention to 
                    the advancement requirements, you will notice a lot of flaws 
                    that can easily be fixed if the national office pays attention 
                    and gives it a little bit of time.</p>
                  <h2>What are the Problems?</h2>
                  
              <blockquote> 
                <p class="maintext"><span class="bluetext"><strong>Non-Existent 
                  Merit Badges.</strong></span><br />
                  There are merit badges listed in the &quot;13 and Above&quot; 
                  handbook that has no official requirements tied to them. No 
                  set procedure was provided on how Scouts can work on these merit 
                  badges. They are listed on this website as the <a href="/htm/mbinworks.php">In 
                the Works Merit Badges</a>.</p>
                <p class="maintext"><span class="bluetext"><strong>Non-Eagle Merit 
                  Badges.</strong></span><br />
                  Merit badges that has tied official requirements can be classified 
                into four types (at least I classify them into such):</p>
                <ol class="maintext">
                  <li> 
                    <p>Eagle Required Merit Badges</p>
                  </li>
                  <li> 
                    <p>Eagle Optionally Required Merit Badges (ex. Tree Farming, 
                      Ecology) </p>
                  </li>
                  <li> 
                    <p>Specialist Rating Merit Badges</p>
                  </li>
                  <li> 
                    <p>Non-Eagle Merit Badges</p>
                  </li>
                </ol>
                <p class="maintext">The <strong>Non-Eagle Merit Badges</strong> 
                  are merit badges that a Scout can earn, but it cannot be credited 
                  towards a Scout's advancement towards Eagle Scout. These merit 
                  badges are not made specifically required and they are not part 
                  of any specialist rating. Note that a merit badge is credit 
                  towards Eagle if it was specifically required by the rank requirements 
                  or it was earned as part of a specialist rating. </p>
                <p class="maintext">There are at least 40 Non-Eagle Merit Badges 
                  as of this time.</p>
                <p class="maintext"><span class="bluetext"><strong>Un-Earnable 
                  Specialist Ratings.</strong></span><br />
                  The first step in <a href="/htm/specialist.php">earning a specialist 
                  rating</a> is to select three merit badges under the specialist 
                  rating that you have not earned previously. There are specialist 
                  ratings that includes merit badges that are required for Eagle 
                  Scout (which automatically disqualifies them from being part 
                  of the three) and leaves the specialist rating with less than 
                three merit badges.</p>
                <p class="maintext"><a href="/img/images/advltr01.jpg"><img src="/img/images/advltr03.jpg" width="127" height="161" border="0" align="right" /></a>The 
                  Merit Badge Center has removed these un-earnable specialist 
                  ratings from our list of specialist ratings. There are six of 
                  these specialist rating in the &quot;13 and Above&quot; handbook.                </p>
                <p class="maintext">I have written a letter to the Program Division 
                  of the National Headquarters in 1999 and did receive a quick 
                  response from Director Rogelio Villa. Until today, the revised 
                  future editions of the requirements he had mentioned in his 
                  response letter has not surfaced.</p>
                <p class="maintext"><strong><span class="bluetext">Rank Requirements 
                  Problem.</span></strong><br />
                  In the Airman Rank (Air Scout track) and Seaman Rank (Sea Scout 
                  track) the requirements can never be completed due to required 
                  merit badges without officially tied requirements to them. They 
                  are the <strong>Airplane Modelling</strong> and <strong>Survival 
                Swimming</strong> Merit Badges respectively.</p>
                <p class="maintext">There is also a problem with the specialist 
                  rating required for the Venturer Rank (Traditional Scout track) 
                  since on the &quot;13 and Above&quot; handbook the specialist 
                  rating <strong>Scout Conservationist</strong> does not exists. 
                  Although it does exists in the proof edition of the handbook, 
                  there are only two merit badges left to earn after you eliminate 
                  all the merit badges that are required for Eagle Scout.</p>
                <p class="maintext">&nbsp;</p>
              </blockquote>
              <!-- InstanceEndEditable --></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellpadding="3" cellspacing="1" class="tablebordertopbot">
          <tr>
            <td width="50%">Copyright &copy; 2020, Merit Badge Center, Philippines<br />
              Since August 4, 1999 - Fourth Edition September 30, 2003 </td>
            <td width="50%" align="right" background="/htm/pub/mbcpterms.php" class="fineprint"><a href="/htm/pub/mbcpterms.php" class="stealth">Terms, Conditions, and Information</a> </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellspacing="1" cellpadding="3">
          <tr>
            <td>
				
			</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
