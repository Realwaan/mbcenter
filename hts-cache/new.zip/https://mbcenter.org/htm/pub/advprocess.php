<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/mbcptemplate2007_2.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="fb:app_id" content="167734213309548"/>
<link rel="shortcut icon" href="/img/mbcp.ico" />
<script type="text/JavaScript" src="/script/genscripts2007.js"></script>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines</title>
<!-- InstanceEndEditable -->
<link href="/css/mainstyle2007.css" rel="stylesheet" type="text/css" />
<!-- InstanceBeginEditable name="head" --><!-- InstanceEndEditable -->
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=204511906280785";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td bgcolor="#FFFFFF"><img src="/img/banner_main_2007.jpg" alt="Merit Badge Center, Philippines" width="768" height="86" /></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="25%" valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
              </tr>         
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/advancement.php" class="mainlink">Advancement Ranks</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/" class="mainlink" >Merit Badges (Alphabetical)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbcitizenrequired.php" class="mainlink" >Merit Badges (Citizen Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbeaglerequired.php" class="mainlink" >Merit Badges (Eagle Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbelectives.php" class="mainlink" >Merit Badges (Electives)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/ws.php" class="mainlink" >Advancement Worksheets</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/contactus/" class="mainlink" >Contact Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/aboutus.php" class="mainlink" >About Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/sitehelp.php" class="mainlink" >Help</a></td>
              </tr>
			  <tr>
			  	<td class="maintext">&nbsp;</td>
			  </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" --> <br />
            <p>&nbsp;</p>
            <p>&nbsp; </p>
            <!-- InstanceEndEditable -->            
              </td>
              <td valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="5">
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><!-- InstanceBeginEditable name="MainBody" --> 
                  <h1>Scout Advancement Process </h1>
                  <p class="maintext">There are four steps in advancement:</p>
                  <ul class="maintext">
                    <li>Preparation</li>
                    <li>Examination</li>
                    <li>Review</li>
                    <li>Recognition</li>
              </ul>
                  <h2>Preparation</h2>
                  <p class="maintext">A boy, knowing what is required
                    of him, prepares to earn a requirement through his participation
                    in regular Scouting activities of the unit. His preparation
                    can be done on his own as well or with the help of his fellow
                    Scouts from his unit or Patrol/Crew.</p>
                  <h2>Examination</h2>
                  <p class="maintext">Once a Scout believes he is
                    ready, he presents himself to be examined for a requirement.
                    The requirement should be taken at face-value, that is, if
                    it stated that he should &quot;Explain&quot; he should do no more,
                    or no less, than explain what needs to be explained, if it
                    stated &quot;Demonstrate&quot; he should do no more, or no less, than
                    demonstrate what needs to be demonstrated. The examination
                    is not a formal examination such as those done in school. </p>
                  <p class="maintext">A Scout can be examined by members of his Patrol/Crew or
                    Troop/Outfit who have already earned the badge he is being
                    examined for. In the case of a Merit Badge, he should only
                    be examined by the Merit Badge Counselor or those the Merit
                    Badge Counselor accepts as examiners.</p>
                  <p class="maintext">Once the Merit Badge Counselor signs off the application,
                    the boy can now appear before a board of review for the Merit
                    Badge. </p>
                  <p class="maintext">In the case of advancement ranks, the boy must also undergo
                    a conference with the Troop Leader/Outfit Advisor. This is
                    an informal conference where the unit leader does a check-up
                    on the Scout on he is doing and get a feedback from the Scout
                    if he is enjoying himself in the program. When the unit leader
                    is satisfied with the Scout's progress, he signs off for
                    the boy to appear before a board of review. </p>
                  <h2>Review</h2>
                  <p class="maintext"> The Board of Review is a panel
                    of adults who are considered friend of Scouting. They can
                    be members of your Institutional Scouting Committee, a member
                    of the parish the Scout goes to, or other adults who cares
                    about the boys progress. Their duty to to make sure that
                    the boy is getting the most out of his Scouting advancement.
                    It is not their place to test the Scout or find faults in
                    him. They will however, make the ultimate decision on whether
                    the Scout is conferred the badge. </p>
                  <p class="maintext">Once the Board of Review confers the badge
                    on the Scout, the unit must report this to the local council
                    at the soonest possible time for recording and issuance of
                    certificates.</p>
                  <h2>Recognition</h2>
                  <p class="maintext">A Court of Honor ceremony is to be arranged
                    to present the Scout with his new Merit Badge or Rank. Parents
                    and friends of the Scout should be invited to attend and
                    make this ceremony a special event. </p>
                  <p class="maintext">Eagle Scout Awards, the highest advancement
                    award in Scouting, should be presented on its own special
                    Court of Honor. </p>
                  <p class="maintext">&nbsp; </p>
          <!-- InstanceEndEditable --></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellpadding="3" cellspacing="1" class="tablebordertopbot">
          <tr>
            <td width="50%">Copyright &copy; 2020, Merit Badge Center, Philippines<br />
              Since August 4, 1999 - Fourth Edition September 30, 2003 </td>
            <td width="50%" align="right" background="/htm/pub/mbcpterms.php" class="fineprint"><a href="/htm/pub/mbcpterms.php" class="stealth">Terms, Conditions, and Information</a> </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellspacing="1" cellpadding="3">
          <tr>
            <td>
				
			</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
