<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/mbcptemplate2007_2.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="fb:app_id" content="167734213309548"/>
<link rel="shortcut icon" href="/img/mbcp.ico" />
<script type="text/JavaScript" src="/script/genscripts2007.js"></script>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines</title>
<!-- InstanceEndEditable -->
<link href="/css/mainstyle2007.css" rel="stylesheet" type="text/css" />
<!-- InstanceBeginEditable name="head" -->
<style type="text/css">
<!--
.style1 {color: #FFFFFF}

.style3 {
	font-family: Arial, Helvetica, sans-serif;
	color: #006600;
	font-weight: bold;
}
a.red {
	color: #CC0000;
	text-decoration: none;
	border-bottom-width: 1pt;
	border-bottom-style: solid;
	border-bottom-color: #CC0000;
}
a.red:hover {

	color: #CC9900;
	text-decoration: none;
	border-bottom-width: 1px;
	border-bottom-style: dotted;
	border-bottom-color: #CC9900;
}

-->
</style><!-- InstanceEndEditable -->
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=204511906280785";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td bgcolor="#FFFFFF"><img src="/img/banner_main_2007.jpg" alt="Merit Badge Center, Philippines" width="768" height="86" /></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="25%" valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
              </tr>         
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/advancement.php" class="mainlink">Advancement Ranks</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/" class="mainlink" >Merit Badges (Alphabetical)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbcitizenrequired.php" class="mainlink" >Merit Badges (Citizen Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbeaglerequired.php" class="mainlink" >Merit Badges (Eagle Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbelectives.php" class="mainlink" >Merit Badges (Electives)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/ws.php" class="mainlink" >Advancement Worksheets</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/contactus/" class="mainlink" >Contact Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/aboutus.php" class="mainlink" >About Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/sitehelp.php" class="mainlink" >Help</a></td>
              </tr>
			  <tr>
			  	<td class="maintext">&nbsp;</td>
			  </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" --> 
                        <p><a href="http://www.adobe.com/products/acrobat/readstep2.html" target="_blank"><img src="/img/images/ico_adobeacrobat.gif" alt="Get Adobe Acrobat Reader" border="0" /></a></p>
                        <p>&nbsp;</p>
            <!-- InstanceEndEditable -->            
              </td>
              <td valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="5">
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><!-- InstanceBeginEditable name="MainBody" --> 
              <h1>Advancement Worksheets (Pre-Passport)</h1>
              <p class="maintext"><strong style="color:#FF0000">NOTE: This page shows requirement that are prior to 2019 or before the current Passport Program. These are not the current requirements and are maintained for program transition purpose. Visit the main <a href="/htm/pub/ws.php">Worksheets</a> page for the most current program of the Boy Scouts of the Philippines.</strong>              </p>
              <h2>Advancement Rank (Pre Passport)</h2>
              <blockquote>
                <table width="90%" border="0" cellpadding="0" cellspacing="0" bgcolor="#69735A">
                  <tr>
                    <td><table width="100%" height="75" border="0" cellpadding="2" cellspacing="1" class="maintext">
                        <tr>
                          <td bgcolor="#BDC9BA" width="44%"><strong>Advancement Rank </strong></td>
                          <td align="center" bgcolor="#BDC9BA"><strong>Adobe
                            PDF </strong></td>
                          <td align="center" bgcolor="#BDC9BA"><strong>Word Doc</strong></td>
                          <td align="center" bgcolor="#BDC9BA"><strong>Last Update</strong></td>
                        </tr>
                        <tr>
                          <td width="56%" bgcolor="#FFFFFF"><a href="/htm/ranks.php?rnk=bsmembership">Membership Badge (Boy Scout)</a></td>
                          <td width="22%" align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_rnk_bsmembership.pdf">PDF</a></td>
                          <td width="22%" align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_rnk_bsmembership.doc">DOC</a></td>
                          <td width="22%" align="center" bgcolor="#FFFFFF">&nbsp;</td>
                        </tr>
                        <tr>
                          <td bgcolor="#FFFFFF"><a href="/htm/ranks.php?rnk=bstenderfoot">Tenderfoot Class Scout</a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_rnk_bstenderfoot.pdf">PDF</a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_rnk_bstenderfoot.doc">DOC</a></td>
                          <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                        </tr>
                        <tr>
                          <td bgcolor="#FFFFFF"><a href="/htm/ranks.php?rnk=bssecondclass">Second Class Scout </a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_rnk_bssecondclass.pdf">PDF</a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_rnk_bssecondclass.doc">DOC</a></td>
                          <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                        </tr>
                        <tr>
                          <td bgcolor="#FFFFFF"><a href="/htm/ranks.php?rnk=bsfirstclass">First Class Scout </a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_rnk_bsfirstclass.pdf">PDF</a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_rnk_bsfirstclass.doc">DOC</a></td>
                          <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                        </tr>
                        <tr>
                          <td bgcolor="#FFFFFF"><a href="/htm/ranks.php?rnk=ssmembership">Membership Badge (Senior Scout) </a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_rnk_ssmembership.pdf">PDF</a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_rnk_ssmembership.doc">DOC</a></td>
                          <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                        </tr>
                        <tr>
                          <td bgcolor="#FFFFFF"><a href="/htm/ranks.php?rnk=ssexplorer">Explorer Scout </a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_rnk_ssexplorer.pdf">PDF</a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_rnk_ssexplorer.doc">DOC</a></td>
                          <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                        </tr>
                        <tr>
                          <td bgcolor="#FFFFFF"><a href="/htm/ranks.php?rnk=sspathfinder">Pathfinder Scout</a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_rnk_sspathfinder.pdf">PDF</a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_rnk_sspathfinder.doc">DOC</a></td>
                          <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                        </tr>
                        <tr>
                          <td bgcolor="#FFFFFF"><a href="/htm/ranks.php?rnk=advoutdoorsman">Outdoorsman Scout</a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_rnk_advoutdoorsman.pdf">PDF</a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_rnk_advoutdoorsman.doc">DOC</a></td>
                          <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                        </tr>
                        <tr>
                          <td bgcolor="#FFFFFF"><a href="/htm/ranks.php?rnk=advventurer">Venturer Scout</a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_rnk_advventurer.pdf">PDF</a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_rnk_advventurer.doc">DOC</a><a href="/pub/ws/ws_rnk_advventurer.pdf"></a></td>
                          <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                        </tr>
                        <tr>
                          <td bgcolor="#FFFFFF"><a href="/htm/ranks.php?rnk=adveagle">Eagle Scout</a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_rnk_adveagle.pdf">PDF</a></td>
                          <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_rnk_adveagle.doc">DOC</a></td>
                          <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                        </tr>

                    </table></td>
                  </tr>
                </table>
              </blockquote>
              <p class="h2">Merit Badges Required for Eagle (Pre Passport)</p>
              <blockquote>
                <table width="90%" border="0" cellpadding="0" cellspacing="0" bgcolor="#69735A">
                  <tr>
                    <td><table width="100%" height="75" border="0" cellpadding="2" cellspacing="1" class="maintext">
                      <tr>
                        <td bgcolor="#BDC9BA" width="44%"><span class="maintext"><strong>Merit Badge </strong></span></td>
                        <td align="center" bgcolor="#BDC9BA"><span class="maintext"><strong>Adobe PDF </strong></span></td>
                        <td align="center" bgcolor="#BDC9BA"><span class="maintext"><strong>Word Doc</strong></span></td>
                        <td align="center" bgcolor="#BDC9BA"><strong>Last Update</strong></td>
                      </tr>
                      <tr>
                        <td width="56%" bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=boating">Boating</a></td>
                        <td width="22%" align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_boating.pdf">PDF</a></td>
                        <td width="22%" align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_boating.doc">DOC</a></td>
                        <td width="22%" align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=camping">Camping</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_camping.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_camping.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=citizenshipinthecommunity">Citizenship in the Community </a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_citizenshipinthecommunity.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_citizenshipinthecommunity.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=citizenshipinthehome">Citizenship in the Home</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_citizenshipinthehome.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_citizenshipinthehome.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=citizenshipinthenation">Citizenship in the Nation </a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_citizenshipinthenation.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_citizenshipinthenation.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=ecology">Ecology</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_ecology.pdf">PDF </a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_ecology.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=electricity">Electricity</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_electricity.pdf">PDF </a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_electricity.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=emergencypreparedness">Emergency Preparedness </a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_emergencypreparedness.pdf">PDF </a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_emergencypreparedness.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=filipinoheritage">Filipino Heritage </a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_filipinoheritage.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_filipinoheritage.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=firstaid">First Aid </a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_firstaid.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_firstaid.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=gogreen">Go Green</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_gogreen.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_gogreen.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=growgreen">Grow Green</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_growgreen.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_growgreen.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=lifesaving">Lifesaving</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_lifesaving.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_lifesaving.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=physicalfitness">Physical Fitness </a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_physicalfitness.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_physicalfitness.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=n&amp;mb=ropework">Ropework</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_ropework.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_ropework.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=safety">Safety</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_safety.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_safety.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=soilandwaterconservation">Soil and Water Conservation </a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_soilandwaterconservation.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_soilandwaterconservation.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=swimming">Swimming</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_swimming.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_swimming.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=treefarming">Tree Farming </a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_treefarming.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_treefarming.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=weather">Weather</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_weather.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_weather.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                      <tr>
                        <td bgcolor="#FFFFFF"><a href="/htm/meritbadges.php?req=y&amp;mb=worldbrotherhood">World Brotherhood </a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/ws_worldbrotherhood.pdf">PDF</a></td>
                        <td align="center" bgcolor="#FFFFFF"><a href="/pub/ws/doc/ws_worldbrotherhood.doc">DOC</a></td>
                        <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
                      </tr>
                    </table></td>
                  </tr>
                </table>
              </blockquote>
              <blockquote>
                <p>&nbsp;</p>
        </blockquote>
              <!-- InstanceEndEditable --></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellpadding="3" cellspacing="1" class="tablebordertopbot">
          <tr>
            <td width="50%">Copyright &copy; 2020, Merit Badge Center, Philippines<br />
              Since August 4, 1999 - Fourth Edition September 30, 2003 </td>
            <td width="50%" align="right" background="/htm/pub/mbcpterms.php" class="fineprint"><a href="/htm/pub/mbcpterms.php" class="stealth">Terms, Conditions, and Information</a> </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellspacing="1" cellpadding="3">
          <tr>
            <td>
				
			</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
