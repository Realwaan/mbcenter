<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/mbcptemplate2007_2.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="fb:app_id" content="167734213309548"/>
<link rel="shortcut icon" href="/img/mbcp.ico" />
<script type="text/JavaScript" src="/script/genscripts2007.js"></script>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines</title>
<!-- InstanceEndEditable -->
<link href="/css/mainstyle2007.css" rel="stylesheet" type="text/css" />
<!-- InstanceBeginEditable name="head" --><!-- InstanceEndEditable -->
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=204511906280785";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td bgcolor="#FFFFFF"><img src="/img/banner_main_2007.jpg" alt="Merit Badge Center, Philippines" width="768" height="86" /></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="25%" valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
              </tr>         
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/advancement.php" class="mainlink">Advancement Ranks</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/" class="mainlink" >Merit Badges (Alphabetical)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbcitizenrequired.php" class="mainlink" >Merit Badges (Citizen Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbeaglerequired.php" class="mainlink" >Merit Badges (Eagle Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbelectives.php" class="mainlink" >Merit Badges (Electives)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/ws.php" class="mainlink" >Advancement Worksheets</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/contactus/" class="mainlink" >Contact Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/aboutus.php" class="mainlink" >About Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/sitehelp.php" class="mainlink" >Help</a></td>
              </tr>
			  <tr>
			  	<td class="maintext">&nbsp;</td>
			  </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" -->
                        <p>&nbsp;</p>
            <!-- InstanceEndEditable -->            
              </td>
              <td valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="5">
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><!-- InstanceBeginEditable name="MainBody" --> 
                  <h1>                  Linking to the Merit Badge Center</h1>
                  <p class="maintext">There are many ways to link to the Merit
                    Badge Center.</p>
                  <h2><strong>Text Link</strong></h2>
                  <p class="maintext">You may link to <a href="javascript:;">meritbadge.org.ph</a>.</p>
                  <h2><strong>Specific Merit Badges</strong></h2>
                  <p class="maintext">You may link to specific merit badges using
                    the URL:</p>
                  <blockquote>
                    <p class="maintext">http://www.mbcenter.org/meritbadges.php?mb=<strong><em>meritbadge</em></strong></p>
                  </blockquote>
                  <p class="maintext">Simply change &quot;meritbadge&quot; with the exact
                    name of the Merit Badge you want to link to in lower case
                    and with no space whatsoever.</p>
                  <p class="maintext">To link to <strong>Soil and Water Conservation</strong> simply
                    link to:</p>
                  <blockquote>
                    <p class="maintext"><a href="http://www.mbcenter.org/htm/meritbadges.php?mb=soilandwaterconservation">http://www.mbcenter.org/meritbadges.php?mb=soilandwaterconservation</a> </p>
                  </blockquote>
                  <h2><strong>Banner Ads </strong></h2>
                  <p class="maintext">Use any of the following image to link
                    to the Merit Badge Center. </p>
                  <p class="maintext">Whenever using these ads, link to<a href="javascript:;"> <strong>http://www.meritbadge.org.ph</strong></a>. </p>
                  <h2>(120x60)</h2>
              <p><img src="/img/images/banner_120x60_1.gif" alt="Merit Badge Center" width="120" height="60" border="0" /> <img src="/img/images/banner_120x60_2.gif" alt="Merit Badge Center" width="120" height="60" border="0" /></p>
              <h2>(120x240)</h2>
              <p><img src="/img/images/bannerad_120x240.gif" alt="Merit Badge Center" width="120" height="240" /> <img src="/img/images/bannerad_120x240_2.gif" alt="Merit Badge Center" width="120" height="240" /></p>
              <h2>(125x125)</h2>
              <h2><img src="/img/images/bannerad_125x125.gif" alt="Merit Badge Center" width="125" height="125" /> <img src="/img/images/bannerad_125x125_2.gif" alt="Merit Badge Center" width="125" height="125" /></h2>
              <h2>(468x60)</h2>
              <p class="maintext"><img src="../img/images/bannerad_468x60.gif" alt="Merit Badge Center" width="468" height="60" border="0" /></p>
                  <p><img src="/img/images/bannerad_468x60_2.gif" alt="Merit Badge Center" width="468" height="60" border="0" /></p>
              <p>&nbsp;</p>
              <!-- InstanceEndEditable --></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellpadding="3" cellspacing="1" class="tablebordertopbot">
          <tr>
            <td width="50%">Copyright &copy; 2020, Merit Badge Center, Philippines<br />
              Since August 4, 1999 - Fourth Edition September 30, 2003 </td>
            <td width="50%" align="right" background="/htm/pub/mbcpterms.php" class="fineprint"><a href="/htm/pub/mbcpterms.php" class="stealth">Terms, Conditions, and Information</a> </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellspacing="1" cellpadding="3">
          <tr>
            <td>
				
			</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
