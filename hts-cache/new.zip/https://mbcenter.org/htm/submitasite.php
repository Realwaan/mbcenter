<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/mbcptemplate2007_2.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="fb:app_id" content="167734213309548"/>
<link rel="shortcut icon" href="/img/mbcp.ico" />
<script type="text/JavaScript" src="/script/genscripts2007.js"></script>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines :: Submit a Site</title>
<!-- InstanceEndEditable -->
<link href="/css/mainstyle2007.css" rel="stylesheet" type="text/css" />
<!-- InstanceBeginEditable name="head" --> 
<style type="text/css">
<!--
a.biglink {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #006600;
	text-decoration: none;
}
a.biglink:hover {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #006600;
	text-decoration: none;
}
-->
</style>
<!-- InstanceEndEditable -->
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=204511906280785";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td bgcolor="#FFFFFF"><img src="/img/banner_main_2007.jpg" alt="Merit Badge Center, Philippines" width="768" height="86" /></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="25%" valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
              </tr>         
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/advancement.php" class="mainlink">Advancement Ranks</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/" class="mainlink" >Merit Badges (Alphabetical)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbcitizenrequired.php" class="mainlink" >Merit Badges (Citizen Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbeaglerequired.php" class="mainlink" >Merit Badges (Eagle Required)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/mbelectives.php" class="mainlink" >Merit Badges (Electives)</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/ws.php" class="mainlink" >Advancement Worksheets</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/contactus/" class="mainlink" >Contact Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/aboutus.php" class="mainlink" >About Us</a></td>
              </tr>
              <tr>
                <td bgcolor="#BDC9BA" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/htm/pub/sitehelp.php" class="mainlink" >Help</a></td>
              </tr>
			  <tr>
			  	<td class="maintext">&nbsp;</td>
			  </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" -->
					  
            <!-- InstanceEndEditable -->            
              </td>
              <td valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="5">
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><!-- InstanceBeginEditable name="MainBody" --> 
                  <h1>Submit A Site</h1>
                  <p class="maintext">We include new web sites and pages on a regular basis into our resource link database. All submissions are reviewed thoroughly against the acceptable web site/page policy. </p>
                  <h2>Steps to Submit a Site</h2>
                  <ol>
                <li class="maintext">Check if the site is already included as 
                  part of the intended <a href="/htm/resources.php">merit badge's 
                  resource links</a> (our resource links page will display all 
                  the resources linked from this site, <strong>it might take some 
                  time to download</strong>).</li>
                <li class="maintext">Check the site against the acceptable site 
                  policy found below.</li>
                <li class="maintext">Submit the site using our form below. Email 
                  submissions will no longer be accepted:</li>
              </ol>
              <form action="/htm/mbprocesssubmit.php" method="post" name="form1" target="_self" id="form1">
                <table width="100%" border="0" align="center">
                  <tr> 
                    <td width="25%" height="35" align="right" valign="top" class="maintext"><div align="right"><strong>Merit 
                        Badge </strong></div></td>
                    <td width="75%" align="left" valign="top"> <input name="mb" type="text" id="mb" size="50" /> 
                      <br /> 
                      <span class="fineprint">Example. Firemanship 4.a., Explorer
                      Scout, Sponosred Link </span></td>
                  </tr>
                  <tr> 
                    <td align="right" valign="top" class="maintext"><strong>Web 
                      Address </strong></td>
                    <td align="left" valign="top"><input name="url" type="text" id="url" value="http://" size="50" /></td>
                  </tr>
                  <tr> 
                    <td height="24" align="right" valign="top" class="maintext"><strong>Short 
                      Description</strong><strong> </strong></td>
                    <td align="left" valign="top"><input name="des" type="text" id="des" size="50" /></td>
                  </tr>
                  <tr> 
                    <td height="24" align="right" valign="top" class="maintext"><strong>Email 
                      Address</strong> </td>
                    <td align="left" valign="top"><input name="email" type="text" id="email" size="50" /></td>
                  </tr>
                </table>
                <p class="fineprint"><strong>NOTICE:</strong> Before submitting 
                  the URL above, please review the web site/page your are submitting 
                  against our <strong>Acceptable Web Site/Page Policy</strong> 
                  for resource links. </p>
                <table width="99" border="0" align="center">
                  <tr> 
                    <td width="45"><div align="center"> 
                        <input type="submit" name="Submit" value="Submit URL" />
                      </div></td>
                    <td width="44"><input name="Reset" type="reset" id="Reset" value="Clear Form" /></td>
                  </tr>
                  <tr align="center"> 
                    <td colspan="2" class="fineprint">&nbsp;</td>
                  </tr>
                </table>
              </form>
                  <h2>Acceptable Web Site/Page Policy</h2>
                  
              <span class="maintext">The merit badge center has the following 
              criteria on web sites/pages used as resource links: </span> 
              <ul class="maintext">
                <li class="maintext">The web site/page should provide information 
                  that is helpful in earning merit badge requirement(s). 
                  <ul>
                    <li>The infomration should be provided for free.</li>
                    <li>The information should be in a publicly accessible area 
                      requiring no registration.</li>
                  </ul>
                </li>
                <li>The website should be free from foul language, obscenity, 
                  or any content or material that is inappropriate for minors 
                  and in breach of &quot;Safe Haven&quot;.</li>
                <li class="maintext">The website's commercial nature (if any) 
                  should not dominate the site/page. The free information should 
                  not be interlaced with the promotion of a specific commerical 
                  product and should not be overhwhelmed by banner or pop-up ads.</li>
              </ul>
              <p class="fineprint">Last Revised June 5, 2005 8:50PM (US PDT)</p>
              <p>&nbsp;</p>
              <!-- InstanceEndEditable --></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellpadding="3" cellspacing="1" class="tablebordertopbot">
          <tr>
            <td width="50%">Copyright &copy; 2020, Merit Badge Center, Philippines<br />
              Since August 4, 1999 - Fourth Edition September 30, 2003 </td>
            <td width="50%" align="right" background="/htm/pub/mbcpterms.php" class="fineprint"><a href="/htm/pub/mbcpterms.php" class="stealth">Terms, Conditions, and Information</a> </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF" class="fineprint"><table width="100%" border="0" cellspacing="1" cellpadding="3">
          <tr>
            <td>
				
			</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
<!-- InstanceEnd --></html>
