<html><!-- InstanceBegin template="/Templates/mbcptemplate2005.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines</title>
<!-- InstanceEndEditable --> 
<script type="text/JavaScript" src="/script/genscripts.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.tableborderright {
	border-right-width: 1px;
	border-right-style: solid;
	border-right-color: #999999;
}
.tablebordertopbot {
	border-top-width: 1px;
	border-bottom-width: 1px;
	border-top-style: solid;
	border-bottom-style: solid;
	border-top-color: #999999;
	border-bottom-color: #999999;
}
.navborder {
	border-bottom-width: 1px;
	border-bottom-style: dashed;
	border-bottom-color: #999999;
}
.navbanner {
	font-family: Georgia, "Times New Roman", Times, serif;
	font-size: 12px;
	font-weight: bold;
	color: #003300;
	border-bottom-width: 1px;
	border-bottom-style: dashed;
	border-bottom-color: #999999;
}
a.mainlink {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #666666;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
a.mainlink:hover {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #000000;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
.txtgray {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #666666;
}
h1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 24px;
	color: #003300;
	font-weight: normal;
}
h2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 18px;
	color: #003300;
	font-weight: normal;
}
.maintext {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000000;
}
.fineprint {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	font-weight: normal;
	color: #666666;
}
.exptext {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 8px;
	text-transform: capitalize;
	letter-spacing: 5px;
}
a {
	color: #007500;
	text-decoration: none;
	border-bottom-style: none;
	border-top-style: none;
	border-right-style: none;
	border-left-style: none;
}
a:hover {
	color: #FFAA0D;
	text-decoration: none;
	border-bottom-width: 1px;
	border-bottom-style: dotted;
	border-bottom-color: #FFAA0D;
}
a.icon {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #666666;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
a.icon:hover {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #000000;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
-->
</style>
<!-- InstanceBeginEditable name="head" --><!-- InstanceEndEditable --> 
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td><table border="0" cellpadding="0" cellspacing="0" width="768">
        <!-- fwtable fwsrc="banner20050421.png" fwbase="banner20050421.gif" fwstyle="Dreamweaver" fwdocid = "742308039" fwnested="0" -->
        <tr> 
          <td><img src="/img/banner/spacer.gif" width="288" height="1" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="249" height="1" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="231" height="1" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="1" border="0" alt=""></td>
        </tr>
        <tr> 
          <td><img name="banner20050421_r1_c1" src="/img/banner/banner20050421_r1_c1.gif" width="288" height="49" border="0" alt=""></td>
          <td><a href="http://www.philippinewebawards.com" target="_blank"><img name="banner20050421_r1_c2" src="/img/banner/banner20050421_r1_c2.gif" width="249" height="49" border="0" alt=""></a></td>
          <td width="231" height="95" rowspan="2" background="/img/banner/banner20050421_r1_c3.gif"><a href="http://www.philippinewebawards.com" target="_blank"></a></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="49" border="0" alt=""></td>
        </tr>
        <tr> 
          <td><img name="banner20050421_r2_c1" src="/img/banner/banner20050421_r2_c1.gif" width="288" height="46" border="0" alt=""></td>
          <td><img name="banner20050421_r2_c2" src="/img/banner/banner20050421_r2_c2.gif" width="249" height="46" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="46" border="0" alt=""></td>
        </tr>
        <tr> 
          <td><img name="banner20050421_r3_c1" src="/img/banner/banner20050421_r3_c1.gif" width="288" height="48" border="0" alt=""></td>
          <td><img name="banner20050421_r3_c2" src="/img/banner/banner20050421_r3_c2.gif" width="249" height="48" border="0" alt=""></td>
          <td><img name="banner20050421_r3_c3" src="/img/banner/banner20050421_r3_c3.gif" width="231" height="48" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="48" border="0" alt=""></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><table width="768" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="191" valign="top" class="tableborderright"><table width="100%" border="0" cellspacing="2" cellpadding="2">
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/welcomepage.php" class="mainlink">Home</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/advancement.php" class="mainlink">Advancement 
                  Ranks</a></td>
              </tr>
              <tr>
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/awards.php" class="mainlink">Awards &amp; Programs</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><p><a href="/meritbadgelist.php" class="mainlink">Merit 
                    Badge (Alpha)</a></p></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><p><a href="/mbeaglerequired.php" class="mainlink">Merit 
                    Badge (Eagle Required)</a></p></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><p><a href="/specialist.php" class="mainlink">Merit 
                    Badge (Specialist)</a></p></td>
              </tr>
              <tr>
                <td background="/mbgroup.php" class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/mbgroup.php" class="mainlink">Merit
                    Badge (by Group)</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/woodbadge/index.php" class="mainlink">Leader 
                  Training</a></td>
              </tr>
              <tr>
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/forms.php" class="mainlink">Forms and Applications</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/pub/index.php" class="mainlink">Publications</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/downloads.php" class="mainlink">Downloads</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/mbcplinks.php" class="mainlink">Sponsored 
                  Links</a></td>
              </tr>
              <tr> 
                <td class="navborder" onmouseover="mOvr1(this);" onmouseout="mOut1(this);" onclick="mClk(this);"><a href="/submitasite.php" class="mainlink">Submit 
                  a Site</a></td>
              </tr>
              <tr> 
                <td class="navborder" onmouseover="mOvr1(this);" onmouseout="mOut1(this);" onclick="mClk(this);"><a href="/contactus.php" class="mainlink">Contact 
                  Us</a></td>
              </tr>
              <tr> 
                <td class="navborder" onmouseover="mOvr1(this);" onmouseout="mOut1(this);" onclick="mClk(this);"><a href="/pub/html/sitehelp.php" class="mainlink">Help</a></td>
              </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" -->
                        <p>&nbsp;</p>
            <!-- InstanceEndEditable --></td>
          <td width="577" valign="top"><blockquote><!-- InstanceBeginEditable name="MainBody" --> 
                  
              <h1>Terms, Conditions, and Information</h1>
              <p class="fineprint">Revised April 30, 2005 8:06 AM (US PDT)</p>
                  <p class="maintext">Welcome to the Merit Badge Center, Philippines!</p>
                  <p class="maintext">The following terms and conditions apply 
                    to all users of this Web Site. By using this Web Site, you agree 
                    to abide and be bound the following terms and conditions.</p>
                  <p class="maintext">The Merit Badge Center reserves the right 
                    to modify the terms and conditions at any time without prior 
                    notice to you. Any such modifications shall take effect from 
                    the moment such policies and terms and conditions are posted 
                    on this Web Site.</p>
                  <h2>Information Collected by this Web Site</h2>
                  <p class="maintext">Through the course of communication, the 
                    Merit Badge Center may request or receive personal information 
                    such as your name and e-mail address. Such information we 
                    receive through this medium are volunteered information or 
                    provided with consent. We do not make these information public 
                    without your permission or knowledge.</p>
                  <p class="maintext">Through the features provided by our host, 
                    the Merit Badge Center collects computer-related information 
                    such as the type and version of your web browser, the type 
                    and version of your operating system, and the Web Site you 
                    are previously on prior to your visit to a Merit Badge Center 
                    page. These information are used to understand our web users 
                    to provide better services. These information are collected 
                    for statistical purposes only and no personally identifying 
                    information are tied to them. These information are collected 
                    automatically and no action is required on your part.</p>
                  <h2>Use of Site Information</h2>
                  <p class="maintext">You may download, view, copy, and print 
                    documents and graphics from this Web Site; provided, that they 
                    are used solely for personal, informational, non-commercial 
                    purposes and may not be modified or altered in any way.</p>
                  <p class="maintext">Except where your use constitutes &quot;fair 
                    use&quot; under copyright law, you may not otherwise use, 
                    download, upload, copy, print, display, perform, reproduce, 
                    publish, license, post, transmit, or distribute any information 
                    from this Web Site in whole or in part without the express 
                    authorization of the Merit Badge Center.</p>
                  
              <h2>General Disclaimer</h2>
              <p class="maintext">The information provided on this Web Site are 
                not official publication, opinion, communication, or authorized 
                text from the Boy Scouts of the Philippines or any of its regional 
                and local subsidiary organizations. Currently, there is no official 
                Internet publication for the Boy Scouts of the Philippines.</p>
              <p class="maintext">All information provided herein is strictly 
                the opinion of the private individual who is making the information 
                available on the Internet.</p>
              <h2>Disclaimer of Warranty</h2>
              <p class="maintext">The materials on this Web Site are provided 
                &quot;as is&quot; and without warranties of any kind, either expressed 
                or implied, to the fullest extent permissible pursuant to applicable 
                law.</p>
              <p class="maintext">The Merit Badge Center disclaims all warranties, 
                expressed or implied, including, but not limited to, implied warranties 
                of merchantability and fitness for a particular purpose.</p>
              <p class="maintext">The Merit Badge Center does not warrant that 
                the functions contained in the materials will be uninterrupted 
                or error-free, that defects will be corrected, or that this Web 
                Site or the server that makes it available is free of viruses 
                or other harmful components.</p>
              <p class="maintext">The Merit Badge Center does not warrant or make 
                any representations regarding the use or the results of the use 
                of the materials on this Web Site in terms of their correctness, 
                accuracy, reliability, or otherwise. </p>
              <h2>Limitation of Liability</h2>
              <p class="maintext">Any content, materials, or information downloaded 
                or otherwise obtained through the use of this Web Site is done 
                at your own discretion and risk.</p>
              <p class="maintext">In no event shall the Merit Badge Center be 
                liable for any direct, indirect, incidental, special, or consequential 
                damages, or damages for loss of profits, revenue, data or use, 
                incurred by you or any third party, whether in an action in contract 
                or tort, arising from your access to, or use of, this Web Site.</p>
              <h2>Indemnity</h2>
              <p class="maintext">You agree to defend, indemnify and hold harmless 
                the Merit Badge Center its sponsor, representatives, officers, 
                and agents from and against any and all claims, liabilities, damages, 
                losses or expenses, including reasonable attorneys' fees and costs, 
                arising out of or in any way connected with your access to or 
                use of this Web Site.</p>
              <h2>Third Party Web Sites, Content, Products, and Services</h2>
              <p class="maintext">The Merit Badge Center provides links to third 
                party web sites (merchants, advertisers, affiliates, sponsors, 
                etc.) and access to their content, products, and services. </p>
              <p class="maintext"> You agree that this Web Site is not responsible 
                for the availability of, and content provided on or by, third 
                party web sites or individuals. You should refer to the policies 
                posted by these web sites regarding privacy and other topics before 
                you use them.</p>
              <p class="maintext">You agree that this Web Site is not responsible 
                for third party content, including opinions, advice, statements, 
                and advertisements, including those posted on our forums, and 
                you understand that you bear all risks associated with the use 
                of such content.</p>
              <p class="maintext">If you choose to purchase any products or services 
                from a third party, your relationship is directly with the third 
                party. You agree that this Web Site is not responsible for: (a) 
                the quality of third party products or services; and (b) fulfilling 
                any of the terms of your agreement with the seller, including 
                delivery of products or services and warranty obligations related 
                to purchased products or services.</p>
              <p class="maintext">You agree that this Web Site is not responsible 
                for any loss or damage of any sort you may incur from dealing 
                with any third party.</p>
              <h2>Copyright/Trademark Information</h2>
              <p class="maintext">The trademarks, logos, and service marks displayed 
                on this Web Site are the property of the Merit Badge Center or 
                other third parties. Users are not permitted to use them without 
                the prior written consent of the Merit Badge Center or such third 
                party which may own such trademarks, logos, and service marks.</p>
              <p class="maintext">All original works of the author of this Web 
                Site, where applicable, is copyrighted (Copyright&copy; 1999-2005) 
                under the laws of the United States of America, specifically in 
                Los Angeles County in the State of California. All Rights Reserved.</p>
              <h2>Contact Information</h2>
              <h2 class="maintext">If you have any questions regarding these Terms 
                of Use, please contact us through e-mail at: <a href="mailto:info@meritbadge.org.ph">info@meritbadge.org.ph</a>.</h2>
              <p></p>
              <!-- InstanceEndEditable --></blockquote></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr> 
          <td class="tablebordertopbot"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="50%"><strong> <span class="txtgray">Copyright &copy; 2006,
                      Merit  Badge Center, Philippines </span></strong></td>
                <td width="50%" align="right" class="txtgray"><strong><a href="/pub/html/mbcpterms.php" class="mainlink">Terms, 
                  Conditions, and Information</a> </strong></td>
              </tr>
            </table>
            
          </td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr>
          <td><p class="fineprint">Since August 4, 1999<br>
              Fourth Edition September 30, 2003<br>
          </p>          </td>
        </tr>
      </table></td>
  </tr>
</table>
<p>&nbsp;</p></body>
<!-- InstanceEnd --></html>
