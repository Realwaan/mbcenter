<html><!-- InstanceBegin template="/Templates/mbcptemplate2005.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines</title>
<!-- InstanceEndEditable --> 
<script type="text/JavaScript" src="/script/genscripts.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.tableborderright {
	border-right-width: 1px;
	border-right-style: solid;
	border-right-color: #999999;
}
.tablebordertopbot {
	border-top-width: 1px;
	border-bottom-width: 1px;
	border-top-style: solid;
	border-bottom-style: solid;
	border-top-color: #999999;
	border-bottom-color: #999999;
}
.navborder {
	border-bottom-width: 1px;
	border-bottom-style: dashed;
	border-bottom-color: #999999;
}
.navbanner {
	font-family: Georgia, "Times New Roman", Times, serif;
	font-size: 12px;
	font-weight: bold;
	color: #003300;
	border-bottom-width: 1px;
	border-bottom-style: dashed;
	border-bottom-color: #999999;
}
a.mainlink {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #666666;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
a.mainlink:hover {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #000000;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
.txtgray {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #666666;
}
h1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 24px;
	color: #003300;
	font-weight: normal;
}
h2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 18px;
	color: #003300;
	font-weight: normal;
}
.maintext {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000000;
}
.fineprint {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	font-weight: normal;
	color: #666666;
}
.exptext {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 8px;
	text-transform: capitalize;
	letter-spacing: 5px;
}
a {
	color: #007500;
	text-decoration: none;
	border-bottom-style: none;
	border-top-style: none;
	border-right-style: none;
	border-left-style: none;
}
a:hover {
	color: #FFAA0D;
	text-decoration: none;
	border-bottom-width: 1px;
	border-bottom-style: dotted;
	border-bottom-color: #FFAA0D;
}
a.icon {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #666666;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
a.icon:hover {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #000000;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
-->
</style>
<!-- InstanceBeginEditable name="head" --><!-- InstanceEndEditable --> 
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td><table border="0" cellpadding="0" cellspacing="0" width="768">
        <!-- fwtable fwsrc="banner20050421.png" fwbase="banner20050421.gif" fwstyle="Dreamweaver" fwdocid = "742308039" fwnested="0" -->
        <tr> 
          <td><img src="/img/banner/spacer.gif" width="288" height="1" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="249" height="1" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="231" height="1" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="1" border="0" alt=""></td>
        </tr>
        <tr> 
          <td><img name="banner20050421_r1_c1" src="/img/banner/banner20050421_r1_c1.gif" width="288" height="49" border="0" alt=""></td>
          <td><a href="http://www.philippinewebawards.com" target="_blank"><img name="banner20050421_r1_c2" src="/img/banner/banner20050421_r1_c2.gif" width="249" height="49" border="0" alt=""></a></td>
          <td width="231" height="95" rowspan="2" background="/img/banner/banner20050421_r1_c3.gif"><a href="http://www.philippinewebawards.com" target="_blank"></a></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="49" border="0" alt=""></td>
        </tr>
        <tr> 
          <td><img name="banner20050421_r2_c1" src="/img/banner/banner20050421_r2_c1.gif" width="288" height="46" border="0" alt=""></td>
          <td><img name="banner20050421_r2_c2" src="/img/banner/banner20050421_r2_c2.gif" width="249" height="46" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="46" border="0" alt=""></td>
        </tr>
        <tr> 
          <td><img name="banner20050421_r3_c1" src="/img/banner/banner20050421_r3_c1.gif" width="288" height="48" border="0" alt=""></td>
          <td><img name="banner20050421_r3_c2" src="/img/banner/banner20050421_r3_c2.gif" width="249" height="48" border="0" alt=""></td>
          <td><img name="banner20050421_r3_c3" src="/img/banner/banner20050421_r3_c3.gif" width="231" height="48" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="48" border="0" alt=""></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><table width="768" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="191" valign="top" class="tableborderright"><table width="100%" border="0" cellspacing="2" cellpadding="2">
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/welcomepage.php" class="mainlink">Home</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/advancement.php" class="mainlink">Advancement 
                  Ranks</a></td>
              </tr>
              <tr>
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/awards.php" class="mainlink">Awards &amp; Programs</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><p><a href="/meritbadgelist.php" class="mainlink">Merit 
                    Badge (Alpha)</a></p></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><p><a href="/mbeaglerequired.php" class="mainlink">Merit 
                    Badge (Eagle Required)</a></p></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><p><a href="/specialist.php" class="mainlink">Merit 
                    Badge (Specialist)</a></p></td>
              </tr>
              <tr>
                <td background="/mbgroup.php" class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/mbgroup.php" class="mainlink">Merit
                    Badge (by Group)</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/woodbadge/index.php" class="mainlink">Leader 
                  Training</a></td>
              </tr>
              <tr>
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/forms.php" class="mainlink">Forms and Applications</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/pub/index.php" class="mainlink">Publications</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/downloads.php" class="mainlink">Downloads</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/mbcplinks.php" class="mainlink">Sponsored 
                  Links</a></td>
              </tr>
              <tr> 
                <td class="navborder" onmouseover="mOvr1(this);" onmouseout="mOut1(this);" onclick="mClk(this);"><a href="/submitasite.php" class="mainlink">Submit 
                  a Site</a></td>
              </tr>
              <tr> 
                <td class="navborder" onmouseover="mOvr1(this);" onmouseout="mOut1(this);" onclick="mClk(this);"><a href="/contactus.php" class="mainlink">Contact 
                  Us</a></td>
              </tr>
              <tr> 
                <td class="navborder" onmouseover="mOvr1(this);" onmouseout="mOut1(this);" onclick="mClk(this);"><a href="/pub/html/sitehelp.php" class="mainlink">Help</a></td>
              </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" --> 
                        <p><a href="http://www.adobe.com/products/acrobat/readstep2.html" target="_blank"><img src="/images/ico_adobeacrobat.gif" alt="Get Adobe Acrobat Reader" border="0" /></a></p>
                        <p>&nbsp;</p>
            <!-- InstanceEndEditable --></td>
          <td width="577" valign="top"><blockquote><!-- InstanceBeginEditable name="MainBody" --> 
              <h1>Merit Badge Worksheets</h1>
              <p class="maintext">Use these worksheet to assist you or your Scouts 
                to do their merit badge work. As of the moment we are just starting 
                this project.</p>
              <h2>Required for Eagle</h2>
              <ul class="maintext">
                <li class="maintext"><a href="/pub/ws/ws_ecology.pdf">Ecology 
                  </a> (152KB)</li>
                <li><a href="/pub/ws/ws_filipinoheritage.pdf">Filipino Heritage</a> 
                  (147KB)</li>
                <li><a href="/pub/ws/ws_firstaid.pdf">First Aid</a> (147KB) </li>
                <li><a href="/pub/ws/ws_citizenshipinthecommunity.pdf">Citizenship 
                  in the Community</a> (175KB)</li>
                <li><a href="/pub/ws/ws_citizenshipinthehome.pdf">Citizenship 
                  in the Home</a> (143KB)</li>
                <li><a href="/pub/ws/ws_citizenshipinthenation.pdf">Citizenship
                in the Nation</a> (170KB) </li>
                <li><a href="/pub/ws/ws_physicalfitness.pdf">Physical Fitness</a> (186KB) </li>
                <li><a href="/pub/ws/ws_safety.pdf">Safety  </a> (157KB)</li>
                <li><a href="/pub/ws/ws_soilandwaterconservation.pdf">Soil and
                Water Conservation</a> (155KB) </li>
                <li><a href="/pub/ws/ws_treefarming.pdf">Tree Farming</a> (126KB)</li>
                <li><a href="/pub/ws/ws_weather.pdf">Weather</a> (189KB) </li>
              </ul>
              <h2>All Other Merit Badges</h2>
              <ul class="maintext">
                <li><a href="/pub/ws/ws_ecology.pdf">Environment</a> (152KB)</li>
              </ul>
              <!-- InstanceEndEditable --></blockquote></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr> 
          <td class="tablebordertopbot"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="50%"><strong> <span class="txtgray">Copyright &copy; 2006,
                      Merit  Badge Center, Philippines </span></strong></td>
                <td width="50%" align="right" class="txtgray"><strong><a href="/pub/html/mbcpterms.php" class="mainlink">Terms, 
                  Conditions, and Information</a> </strong></td>
              </tr>
            </table>
            
          </td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr>
          <td><p class="fineprint">Since August 4, 1999<br>
              Fourth Edition September 30, 2003<br>
          </p>          </td>
        </tr>
      </table></td>
  </tr>
</table>
<p>&nbsp;</p></body>
<!-- InstanceEnd --></html>
