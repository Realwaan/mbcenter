<html><!-- InstanceBegin template="/Templates/mbcptemplate2005.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines</title>
<!-- InstanceEndEditable --> 
<script type="text/JavaScript" src="/script/genscripts.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.tableborderright {
	border-right-width: 1px;
	border-right-style: solid;
	border-right-color: #999999;
}
.tablebordertopbot {
	border-top-width: 1px;
	border-bottom-width: 1px;
	border-top-style: solid;
	border-bottom-style: solid;
	border-top-color: #999999;
	border-bottom-color: #999999;
}
.navborder {
	border-bottom-width: 1px;
	border-bottom-style: dashed;
	border-bottom-color: #999999;
}
.navbanner {
	font-family: Georgia, "Times New Roman", Times, serif;
	font-size: 12px;
	font-weight: bold;
	color: #003300;
	border-bottom-width: 1px;
	border-bottom-style: dashed;
	border-bottom-color: #999999;
}
a.mainlink {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #666666;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
a.mainlink:hover {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #000000;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
.txtgray {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #666666;
}
h1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 24px;
	color: #003300;
	font-weight: normal;
}
h2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 18px;
	color: #003300;
	font-weight: normal;
}
.maintext {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000000;
}
.fineprint {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	font-weight: normal;
	color: #666666;
}
.exptext {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 8px;
	text-transform: capitalize;
	letter-spacing: 5px;
}
a {
	color: #007500;
	text-decoration: none;
	border-bottom-style: none;
	border-top-style: none;
	border-right-style: none;
	border-left-style: none;
}
a:hover {
	color: #FFAA0D;
	text-decoration: none;
	border-bottom-width: 1px;
	border-bottom-style: dotted;
	border-bottom-color: #FFAA0D;
}
a.icon {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #666666;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
a.icon:hover {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #000000;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
-->
</style>
<!-- InstanceBeginEditable name="head" --><!-- InstanceEndEditable --> 
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td><table border="0" cellpadding="0" cellspacing="0" width="768">
        <!-- fwtable fwsrc="banner20050421.png" fwbase="banner20050421.gif" fwstyle="Dreamweaver" fwdocid = "742308039" fwnested="0" -->
        <tr> 
          <td><img src="/img/banner/spacer.gif" width="288" height="1" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="249" height="1" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="231" height="1" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="1" border="0" alt=""></td>
        </tr>
        <tr> 
          <td><img name="banner20050421_r1_c1" src="/img/banner/banner20050421_r1_c1.gif" width="288" height="49" border="0" alt=""></td>
          <td><a href="http://www.philippinewebawards.com" target="_blank"><img name="banner20050421_r1_c2" src="/img/banner/banner20050421_r1_c2.gif" width="249" height="49" border="0" alt=""></a></td>
          <td width="231" height="95" rowspan="2" background="/img/banner/banner20050421_r1_c3.gif"><a href="http://www.philippinewebawards.com" target="_blank"></a></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="49" border="0" alt=""></td>
        </tr>
        <tr> 
          <td><img name="banner20050421_r2_c1" src="/img/banner/banner20050421_r2_c1.gif" width="288" height="46" border="0" alt=""></td>
          <td><img name="banner20050421_r2_c2" src="/img/banner/banner20050421_r2_c2.gif" width="249" height="46" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="46" border="0" alt=""></td>
        </tr>
        <tr> 
          <td><img name="banner20050421_r3_c1" src="/img/banner/banner20050421_r3_c1.gif" width="288" height="48" border="0" alt=""></td>
          <td><img name="banner20050421_r3_c2" src="/img/banner/banner20050421_r3_c2.gif" width="249" height="48" border="0" alt=""></td>
          <td><img name="banner20050421_r3_c3" src="/img/banner/banner20050421_r3_c3.gif" width="231" height="48" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="48" border="0" alt=""></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><table width="768" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="191" valign="top" class="tableborderright"><table width="100%" border="0" cellspacing="2" cellpadding="2">
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/welcomepage.php" class="mainlink">Home</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/advancement.php" class="mainlink">Advancement 
                  Ranks</a></td>
              </tr>
              <tr>
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/awards.php" class="mainlink">Awards &amp; Programs</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><p><a href="/meritbadgelist.php" class="mainlink">Merit 
                    Badge (Alpha)</a></p></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><p><a href="/mbeaglerequired.php" class="mainlink">Merit 
                    Badge (Eagle Required)</a></p></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><p><a href="/specialist.php" class="mainlink">Merit 
                    Badge (Specialist)</a></p></td>
              </tr>
              <tr>
                <td background="/mbgroup.php" class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/mbgroup.php" class="mainlink">Merit
                    Badge (by Group)</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/woodbadge/index.php" class="mainlink">Leader 
                  Training</a></td>
              </tr>
              <tr>
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/forms.php" class="mainlink">Forms and Applications</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/pub/index.php" class="mainlink">Publications</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/downloads.php" class="mainlink">Downloads</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/mbcplinks.php" class="mainlink">Sponsored 
                  Links</a></td>
              </tr>
              <tr> 
                <td class="navborder" onmouseover="mOvr1(this);" onmouseout="mOut1(this);" onclick="mClk(this);"><a href="/submitasite.php" class="mainlink">Submit 
                  a Site</a></td>
              </tr>
              <tr> 
                <td class="navborder" onmouseover="mOvr1(this);" onmouseout="mOut1(this);" onclick="mClk(this);"><a href="/contactus.php" class="mainlink">Contact 
                  Us</a></td>
              </tr>
              <tr> 
                <td class="navborder" onmouseover="mOvr1(this);" onmouseout="mOut1(this);" onclick="mClk(this);"><a href="/pub/html/sitehelp.php" class="mainlink">Help</a></td>
              </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" --> 
                        <p><a href="http://www.adobe.com/products/acrobat/readstep2.html" target="_blank"><img src="/images/ico_adobeacrobat.gif" alt="Get Adobe Acrobat Reader" border="0" /></a></p>
                        <p>&nbsp;</p>
            <!-- InstanceEndEditable --></td>
          <td width="577" valign="top"><blockquote><!-- InstanceBeginEditable name="MainBody" --> 
              <h1>Scouting for Boys</h1>
              <p class="maintext">By Robert Baden-Powell. Originally published 
                in 1908 and now presented in Adobe Acrobat format courtesy of 
                Scouts Canada. Includes original content and art by Robert Baden-Powell. 
                Some of the content no longer applies to present day.</p>
              <blockquote>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn00.pdf">Yarn 
                  00 - Introduction and Explanation of Scouting</a> (227KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn01.pdf">Yarn 
                  01 - Scouts' Work</a> (143KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn02.pdf">Yarn 
                  02 - What Scouts Do</a> (319KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn03.pdf">Yarn 
                  03 - Becoming a Scout</a> (105KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn04.pdf">Yarn 
                  04 - Scout Patrols</a> (147KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn05.pdf">Yarn 
                  05 - Life in the Open </a>(194KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn06.pdf">Yarn 
                  06 - Sea and Air Scouting</a> (46KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn07.pdf">Yarn 
                  07 - Signals and Commands</a> (137KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn08.pdf">Yarn 
                  08 - Pioneering</a> (454KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn09.pdf">Yarn 
                  09 - Camping</a> (471KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn10.pdf">Yarn 
                  10 - Camp Cooking</a> (126KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn11.pdf">Yarn 
                  11 - Observation of &quot;Sign&quot;</a> (271KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn12.pdf">Yarn 
                  12 - Spooring</a> (245KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn13.pdf">Yarn 
                  13 - Reading &quot;Sign&quot; or Observation</a> (221KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn14.pdf">Yarn 
                  14 - Stalking</a> (246KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn15.pdf">Yarn 
                  15 - Animals</a> (372KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn16.pdf">Yarn 
                  16 - Plants</a> (201KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn17.pdf">Yarn 
                  17 - Endurance</a> (383KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn18.pdf">Yarn 
                  18 - Health-Giving Habits</a> (235KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn19.pdf">Yarn 
                  19 - Prevention of Disease </a>(221KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn20.pdf">Yarn 
                  20 - Chivalry to Others</a> (258KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn21.pdf">Yarn 
                  21 - Self-Discipline</a> (216KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn22.pdf">Yarn 
                  22 - Self-Improvement</a> (228KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn23.pdf">Yarn 
                  23 - Be Prepared for Accidents</a> (154KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn24.pdf">Yarn 
                  24 - Accidents</a> (161KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn25.pdf">Yarn 
                  25 - Helping Others</a> (186KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn26.pdf">Yarn 
                  26 - Citizenship</a> (161KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn27.pdf">Yarn 
                  27 - Our Commonwealth and Empire</a> (154KB)</p>
                <p class="maintext"><a href="/downloads/bp_book/sfb/yarn28.pdf">Yarn 
                  28 - Our World-Wide Brotherhood</a> (127KB)</p>
                <p>&nbsp;</p>
              </blockquote>
                  <!-- InstanceEndEditable --></blockquote></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr> 
          <td class="tablebordertopbot"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="50%"><strong> <span class="txtgray">Copyright &copy; 2006,
                      Merit  Badge Center, Philippines </span></strong></td>
                <td width="50%" align="right" class="txtgray"><strong><a href="/pub/html/mbcpterms.php" class="mainlink">Terms, 
                  Conditions, and Information</a> </strong></td>
              </tr>
            </table>
            
          </td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr>
          <td><p class="fineprint">Since August 4, 1999<br>
              Fourth Edition September 30, 2003<br>
          </p>          </td>
        </tr>
      </table></td>
  </tr>
</table>
<p>&nbsp;</p></body>
<!-- InstanceEnd --></html>
