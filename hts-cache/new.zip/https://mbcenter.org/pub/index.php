<html><!-- InstanceBegin template="/Templates/mbcptemplate2005.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<!-- InstanceBeginEditable name="doctitle" --> 
<title>Merit Badge Center, Philippines</title>
<!-- InstanceEndEditable --> 
<script type="text/JavaScript" src="/script/genscripts.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.tableborderright {
	border-right-width: 1px;
	border-right-style: solid;
	border-right-color: #999999;
}
.tablebordertopbot {
	border-top-width: 1px;
	border-bottom-width: 1px;
	border-top-style: solid;
	border-bottom-style: solid;
	border-top-color: #999999;
	border-bottom-color: #999999;
}
.navborder {
	border-bottom-width: 1px;
	border-bottom-style: dashed;
	border-bottom-color: #999999;
}
.navbanner {
	font-family: Georgia, "Times New Roman", Times, serif;
	font-size: 12px;
	font-weight: bold;
	color: #003300;
	border-bottom-width: 1px;
	border-bottom-style: dashed;
	border-bottom-color: #999999;
}
a.mainlink {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #666666;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
a.mainlink:hover {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #000000;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
.txtgray {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #666666;
}
h1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 24px;
	color: #003300;
	font-weight: normal;
}
h2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 18px;
	color: #003300;
	font-weight: normal;
}
.maintext {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000000;
}
.fineprint {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	font-weight: normal;
	color: #666666;
}
.exptext {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 8px;
	text-transform: capitalize;
	letter-spacing: 5px;
}
a {
	color: #007500;
	text-decoration: none;
	border-bottom-style: none;
	border-top-style: none;
	border-right-style: none;
	border-left-style: none;
}
a:hover {
	color: #FFAA0D;
	text-decoration: none;
	border-bottom-width: 1px;
	border-bottom-style: dotted;
	border-bottom-color: #FFAA0D;
}
a.icon {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #666666;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
a.icon:hover {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #000000;
	text-decoration: none;
	font-weight: bold;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
-->
</style>
<!-- InstanceBeginEditable name="head" --><!-- InstanceEndEditable --> 
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="768" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td><table border="0" cellpadding="0" cellspacing="0" width="768">
        <!-- fwtable fwsrc="banner20050421.png" fwbase="banner20050421.gif" fwstyle="Dreamweaver" fwdocid = "742308039" fwnested="0" -->
        <tr> 
          <td><img src="/img/banner/spacer.gif" width="288" height="1" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="249" height="1" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="231" height="1" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="1" border="0" alt=""></td>
        </tr>
        <tr> 
          <td><img name="banner20050421_r1_c1" src="/img/banner/banner20050421_r1_c1.gif" width="288" height="49" border="0" alt=""></td>
          <td><a href="http://www.philippinewebawards.com" target="_blank"><img name="banner20050421_r1_c2" src="/img/banner/banner20050421_r1_c2.gif" width="249" height="49" border="0" alt=""></a></td>
          <td width="231" height="95" rowspan="2" background="/img/banner/banner20050421_r1_c3.gif"><a href="http://www.philippinewebawards.com" target="_blank"></a></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="49" border="0" alt=""></td>
        </tr>
        <tr> 
          <td><img name="banner20050421_r2_c1" src="/img/banner/banner20050421_r2_c1.gif" width="288" height="46" border="0" alt=""></td>
          <td><img name="banner20050421_r2_c2" src="/img/banner/banner20050421_r2_c2.gif" width="249" height="46" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="46" border="0" alt=""></td>
        </tr>
        <tr> 
          <td><img name="banner20050421_r3_c1" src="/img/banner/banner20050421_r3_c1.gif" width="288" height="48" border="0" alt=""></td>
          <td><img name="banner20050421_r3_c2" src="/img/banner/banner20050421_r3_c2.gif" width="249" height="48" border="0" alt=""></td>
          <td><img name="banner20050421_r3_c3" src="/img/banner/banner20050421_r3_c3.gif" width="231" height="48" border="0" alt=""></td>
          <td><img src="/img/banner/spacer.gif" width="1" height="48" border="0" alt=""></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><table width="768" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="191" valign="top" class="tableborderright"><table width="100%" border="0" cellspacing="2" cellpadding="2">
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/welcomepage.php" class="mainlink">Home</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/advancement.php" class="mainlink">Advancement 
                  Ranks</a></td>
              </tr>
              <tr>
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/awards.php" class="mainlink">Awards &amp; Programs</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><p><a href="/meritbadgelist.php" class="mainlink">Merit 
                    Badge (Alpha)</a></p></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><p><a href="/mbeaglerequired.php" class="mainlink">Merit 
                    Badge (Eagle Required)</a></p></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><p><a href="/specialist.php" class="mainlink">Merit 
                    Badge (Specialist)</a></p></td>
              </tr>
              <tr>
                <td background="/mbgroup.php" class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/mbgroup.php" class="mainlink">Merit
                    Badge (by Group)</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/woodbadge/index.php" class="mainlink">Leader 
                  Training</a></td>
              </tr>
              <tr>
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/forms.php" class="mainlink">Forms and Applications</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/pub/index.php" class="mainlink">Publications</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/downloads.php" class="mainlink">Downloads</a></td>
              </tr>
              <tr> 
                <td class="navborder" onMouseOver="mOvr1(this);" onMouseOut="mOut1(this);" onClick="mClk(this);"><a href="/mbcplinks.php" class="mainlink">Sponsored 
                  Links</a></td>
              </tr>
              <tr> 
                <td class="navborder" onmouseover="mOvr1(this);" onmouseout="mOut1(this);" onclick="mClk(this);"><a href="/submitasite.php" class="mainlink">Submit 
                  a Site</a></td>
              </tr>
              <tr> 
                <td class="navborder" onmouseover="mOvr1(this);" onmouseout="mOut1(this);" onclick="mClk(this);"><a href="/contactus.php" class="mainlink">Contact 
                  Us</a></td>
              </tr>
              <tr> 
                <td class="navborder" onmouseover="mOvr1(this);" onmouseout="mOut1(this);" onclick="mClk(this);"><a href="/pub/html/sitehelp.php" class="mainlink">Help</a></td>
              </tr>
            </table>
            <!-- InstanceBeginEditable name="ResourceLinks" --> <br />
            <table width="100%" border="0" cellspacing="2" cellpadding="2">
              <tr> 
                <td class="navbanner">Additional Links</td>
              </tr>
              <tr> 
                <td class="navborder"><a href="mailto:publication@meritbadge.org.ph" class="mainlink">Submit 
                  Your Work</a></td>
              </tr>
            </table>
            <p><a href="http://www.adobe.com/products/acrobat/readstep2.html" target="_blank" class="icon"><img src="/images/ico_adobeacrobat.gif" alt="Get Adobe Acrobat Reader" border="0" /></a></p>
            <p>&nbsp;</p>
            <!-- InstanceEndEditable --></td>
          <td width="577" valign="top"><blockquote><!-- InstanceBeginEditable name="MainBody" --> 
              <h1>Publications</h1>
              <p class="maintext">The following files, unless noted, requires
                 you to have Adobe Acrobat Reader in order to view them.  Please
                contact us for any comments regarding the contents of our publications.</p>
              <p class="maintext"><strong>Do you have original works that are
                  Scouting related that you'd like to share?</strong> If you
                  do, <a href="mailto:publication@meritbadge.org.ph">submit your
                  work</a> to the Merit Badge Center and share with everyone
                  else. Or, if you have a web page where you have your publication <a href="/submitasite.php">submit
                  your page</a> to us and we will include you as a sponsored
              link on this page.</p>
              <h2>Advancement</h2>
              <ul class="maintext">
                <li><span class="maintext"><a href="/pub/pdf/les_conductingbors.pdf">Conducting 
                  Boards of Review</a> (110KB)</span></li>
                <li><span class="maintext"><a href="/pub/pdf/notes_earningmb.pdf">How
                  to Earn a Merit Badge </a>(60KB)<sup>1</sup></span></li>
                <li><span class="maintext"><a href="/pub/pdf/les_meritbadgecounselor.pdf">Merit
                       Badge Counseling</a> (99KB)</span></li>
                <li><a href="/pub/ws.php">Merit Badge Worksheets...</a></li>
                <li><a href="/pub/pdf/les_2mbpolicy.pdf">Response Against the
                  Two Merit Badge Per Month Rationale</a>                  (126KB) </li>
              </ul>
              <h2>Leaders' Library</h2>
              <ul class="maintext">
                <li class="maintext"><a href="/pub/pdf/ll_leadership.pdf">Leadership</a> (223KB)<sup>2</sup></li>
                <li><a href="/pub/pdf/ll_pornonwww.pdf">Pornography on the World
                     Wide Web</a> (201KB)</li>
                <li><a href="/pub/pdf/ll_todomydutystmt.pdf">To Do My Duty</a> (125KB) </li>
                <li><a href="/pub/pdf/ll_youthprotection.pdf">Youth Protection
                Guidelines</a> (145KB) </li>
              </ul>
              <h2>Lord R.S.S. Baden-Powell Books</h2>
              <ul class="maintext">
                <li><a href="/downloads/bp_book/a2s.pdf">Aids to Scoutmastership</a> 
                  (503KB)</li>
                <li><a href="/downloads/bp_book/bpoutlook.pdf">B.-P.'s Outlook</a> 
                  (1.53MB)</li>
                <li><a href="/downloads/bp_book/chiefscoutsyarns.pdf">The Chief
                Scout Yarns</a> (1.58MB) </li>
                <li><a href="/downloads/bp_book/lifesnag.pdf">Life's Snags and 
                  How to Meet Them</a> (904KB)</li>
                <li><a href="/downloads/bp_book/r2s.pdf">Rovering to Success</a> (1.72MB)</li>
                <li><a href="/pub/sfb.php">Scouting for Boys...</a>                </li>
                <li><a href="/downloads/bp_book/bpgames.pdf">Scouting Games</a> (133KB) </li>
              </ul>
              <p class="fineprint"><strong>NOTE:</strong> Books by Robert 
                    Stephenson Smyth Baden-Powell are courtesy of Scouts Canada. 
                    They are presented with their original form. Some of the content 
                    of these manuals may no longer apply to present day practices, 
                    therefore these manuals should only be used in conjunction 
                    with manuals provided by the Boy Scouts of the Philippines 
                    or the National Scout Association you belong to. </p>
              <h2>Notes on Scouting</h2>
              <ul class="maintext">
                <li><a href="/pub/pdf/notes_compass.pdf">Compass Reading</a> (198KB)</li>
                <li><a href="/pub/pdf/notes_estimation.pdf">Estimation of Heights
                and Distances </a>(154KB)</li>
                <li><a href="/pub/pdf/notes_northwocompass.pdf">Finding North
                without a Compass</a> (104KB)</li>
                <li><a href="/pub/pdf/notes_firebuilding.pdf">Fire Building</a> (212KB)</li>
                <li><a href="/pub/pdf/pps_fundamentals.pdf">Fundamental Principles
                of Scouting</a> (113KB) </li>
                <li><a href="/pub/pdf/notes_history101.pdf">History of Scouting</a> (523KB)</li>
                <li><a href="/pub/pdf/notes_flag101.pdf">History of the Philippine
                Flag</a> (158KB)</li>
                <li><a href="/pub/pdf/notes_ideals.pdf">Ideals of Scouting</a> (90KB)</li>
                <li><a href="/pub/pdf/notes_morsecode.pdf">International Morse
                Code</a> (88KB)</li>
                <li><a href="/pub/pdf/notes_scoutsongs01.pdf">Scout Songs</a> (202KB)<sup>3</sup></li>
              </ul>
              <h2>Online Publications</h2>
              <ul class="maintext">
                <li><a href="/history/">The Philippine Scouting Movement: Our 
                  Story </a></li>
              </ul>
              <h2>Power-Point Show</h2>
              <ul>
                <li class="maintext"><a href="/pub/ppt/scouting_fundamental.pps">Fundamental
                Principles of Scouting</a> (512KB)</li>
              </ul>
              <h2>Wood Badge</h2>
              <ul class="maintext">
                <li> <a href="/woodbadge/wb_training02_btc_tl.php">BTC-TL Handouts...</a><sup>4</sup></li>
                <li> <a href="/downloads/wbta.pdf">My Training Assignment</a> 
                  (202KB)</li>
                <li><span class="maintext"><a href="/downloads/wbts.pdf">My Training
                       Studies</a> (197KB)</span></li>
              </ul>
              <p class="fineprint">_____________________<br>
              1 - From the Advancement and Merit Badge Handbook <br>
              2 - From the Grace Christian High School Scout Center<br>
                3 - From Scouter Leonides Son<br>
                4 - From the Filipino-Chinese Scout Club (<em>formerly </em>Friends
                of Scouting Philippines) </p>
              <p class="maintext">&nbsp;</p>
          <!-- InstanceEndEditable --></blockquote></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr> 
          <td class="tablebordertopbot"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="50%"><strong> <span class="txtgray">Copyright &copy; 2006,
                      Merit  Badge Center, Philippines </span></strong></td>
                <td width="50%" align="right" class="txtgray"><strong><a href="/pub/html/mbcpterms.php" class="mainlink">Terms, 
                  Conditions, and Information</a> </strong></td>
              </tr>
            </table>
            
          </td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr>
          <td><p class="fineprint">Since August 4, 1999<br>
              Fourth Edition September 30, 2003<br>
          </p>          </td>
        </tr>
      </table></td>
  </tr>
</table>
<p>&nbsp;</p></body>
<!-- InstanceEnd --></html>
